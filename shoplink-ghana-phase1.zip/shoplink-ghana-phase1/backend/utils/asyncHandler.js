// Wraps an async route handler so any error it throws (or rejects
// with) is forwarded to Express's error-handling middleware instead
// of crashing the process or leaving the request hanging.
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

module.exports = asyncHandler;
