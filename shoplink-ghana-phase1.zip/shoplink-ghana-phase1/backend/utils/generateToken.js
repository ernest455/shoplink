const jwt = require('jsonwebtoken');

// Signs a JWT containing just the user's id. Every protected route
// decodes this token to figure out who is making the request.
const generateToken = (userId) => {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '30d',
  });
};

module.exports = generateToken;
