// Catches every error thrown (or passed to next()) anywhere in the
// app and turns it into the consistent { success, message } shape
// the whole API uses.
const errorHandler = (err, req, res, next) => {
  console.error(err.stack);

  let statusCode = res.statusCode && res.statusCode !== 200 ? res.statusCode : 500;
  let message = err.message || 'Server error';

  // Invalid MongoDB ObjectId (e.g. /api/products/not-a-real-id)
  if (err.name === 'CastError') {
    statusCode = 404;
    message = 'Resource not found';
  }

  // Duplicate key, e.g. registering with an email that already exists
  if (err.code === 11000) {
    statusCode = 400;
    const keySource = err.keyValue || err.keyPattern;
    const field = keySource ? Object.keys(keySource)[0] : 'email';
    message = `An account with that ${field} already exists`;
  }

  // Mongoose schema validation failed
  if (err.name === 'ValidationError') {
    statusCode = 400;
    message = Object.values(err.errors)
      .map((val) => val.message)
      .join(', ');
  }

  res.status(statusCode).json({
    success: false,
    message,
  });
};

// Runs when no route matches the request at all.
const notFound = (req, res, next) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.originalUrl}`,
  });
};

module.exports = { errorHandler, notFound };
