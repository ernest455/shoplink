const rateLimit = require('express-rate-limit');

// Applied to /api/auth/* so an attacker can't hammer login/register
// with thousands of requests per minute.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many attempts. Please try again in a few minutes.',
  },
});

const catalogLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many catalogue requests. Please try again in a minute.',
  },
});

module.exports = { authLimiter, catalogLimiter };
