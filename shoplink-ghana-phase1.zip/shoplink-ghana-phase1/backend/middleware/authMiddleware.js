const jwt = require('jsonwebtoken');
const asyncHandler = require('../utils/asyncHandler');
const User = require('../models/User');

// Verifies the "Authorization: Bearer <token>" header and attaches
// the logged-in user to req.user. Use on any route that should only
// be reachable by a signed-in user.
const protect = asyncHandler(async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    res.status(401);
    throw new Error('Not authorized, no token provided');
  }

  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    res.status(401);
    throw new Error('Not authorized, token failed verification');
  }

  req.user = await User.findById(decoded.id);

  if (!req.user) {
    res.status(401);
    throw new Error('Not authorized, user no longer exists');
  }

  if (req.user.status === 'blocked') {
    res.status(403);
    throw new Error('Your account has been suspended or blocked by platform admin');
  }

  next();
});

// Restricts a route to specific roles. Usage: authorize('admin')
const authorize = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    res.status(403);
    throw new Error('Not authorized to access this resource');
  }
  next();
};

module.exports = { protect, authorize };
