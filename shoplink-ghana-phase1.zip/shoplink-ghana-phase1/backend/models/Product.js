const mongoose = require('mongoose');

const productSchema = new mongoose.Schema(
  {
    storeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Store',
      required: true,
      index: true,
    },
    name: {
      type: String,
      required: [true, 'Product name is required'],
      trim: true,
      maxlength: 120,
    },
    description: { type: String, trim: true, maxlength: 1000, default: '' },
    price: {
      type: Number,
      required: [true, 'Price is required'],
      min: [0, 'Price cannot be negative'],
    },
    category: { type: String, trim: true, default: 'General' },
    images: [{ type: String }],
    published: { type: Boolean, default: true, index: true },
    inStock: { type: Boolean, default: true },
    quantity: { type: Number, default: 0, min: 0 },
    sku: { type: String, trim: true, default: '' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Product', productSchema);
