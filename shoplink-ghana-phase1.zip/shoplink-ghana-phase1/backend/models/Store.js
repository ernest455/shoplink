const mongoose = require('mongoose');

const storeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Store name is required'],
      trim: true,
      maxlength: 100,
    },
    description: { type: String, trim: true, maxlength: 500, default: '' },
    logo: { type: String, default: '' },
    phone: { type: String, trim: true, default: '' },
    email: { type: String, trim: true, lowercase: true, default: '' },
    address: { type: String, trim: true, default: '' },
    city: { type: String, trim: true, default: '' },
    country: { type: String, trim: true, default: 'Ghana' },
    currency: { type: String, trim: true, default: 'GHS' },

    // ── WhatsApp Cloud API config (wired up in Phase 3) ──────────
    whatsappBusinessAccountId: { type: String, default: '' },
    whatsappPhoneNumberId: { type: String, default: '' },
    whatsappAccessToken: {
      type: String,
      default: '',
      select: false, // excluded from every query unless explicitly selected
    },
    whatsappVerifyToken: {
      type: String,
      default: '',
      select: false,
    },

    // ── AI Sales Assistant config (Phase 4) ──────────────────────
    aiEnabled: { type: Boolean, default: true },
    aiPersonality: {
      type: String,
      default: 'Friendly & Professional Ghanaian Sales Assistant',
    },
    aiGreetingMessage: {
      type: String,
      default: 'Hello! Welcome to our store. Feel free to ask about any of our products or place an order!',
    },

    // ── Paystack config (wired up in Phase 5) ────────────────────
    // Only the PUBLIC key is ever stored here - it's safe to show the
    // dashboard. The Paystack SECRET key lives only in .env on the
    // server and must never be saved to the database.
    paystackPublicKey: { type: String, default: '' },

    // ── Subscription & Admin Control ──────────────────────────────
    subscriptionPlan: {
      type: String,
      enum: ['starter', 'business', 'pro'],
      default: 'starter',
    },
    subscriptionStatus: {
      type: String,
      enum: ['trial', 'active', 'past_due', 'cancelled'],
      default: 'trial',
    },
    status: {
      type: String,
      enum: ['active', 'suspended', 'pending'],
      default: 'active',
    },
    suspendedReason: {
      type: String,
      default: '',
    },
  },
  { timestamps: true }
);

// Belt-and-braces: even if a future query forgets to exclude the
// WhatsApp secrets, they're stripped whenever a Store is sent as JSON.
storeSchema.methods.toJSON = function toJSON() {
  const store = this.toObject();
  delete store.whatsappAccessToken;
  delete store.whatsappVerifyToken;
  return store;
};

module.exports = mongoose.model('Store', storeSchema);
