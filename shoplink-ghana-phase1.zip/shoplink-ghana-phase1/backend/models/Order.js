const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema(
  {
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    name:      { type: String, required: true },
    price:     { type: Number, required: true },
    quantity:  { type: Number, required: true, min: 1 },
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema(
  {
    storeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Store',
      required: true,
      index: true,
    },
    orderNumber: { type: String, unique: true },
    customerName:  { type: String, trim: true, default: 'Unknown' },
    customerPhone: { type: String, trim: true, default: '' },
    customerEmail: { type: String, trim: true, lowercase: true, default: '' },
    items:  { type: [orderItemSchema], default: [] },
    total:  { type: Number, default: 0 },
    status: {
      type: String,
      enum: ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'],
      default: 'pending',
    },
    notes: { type: String, trim: true, default: '' },
  },
  { timestamps: true }
);

// Auto-generate a short order number before saving
orderSchema.pre('save', async function (next) {
  if (!this.orderNumber) {
    const count = await mongoose.model('Order').countDocuments({ storeId: this.storeId });
    this.orderNumber = `ORD-${String(count + 1).padStart(4, '0')}`;
  }
  // Recalculate total from items
  if (this.items && this.items.length > 0) {
    this.total = this.items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  }
  next();
});

module.exports = mongoose.model('Order', orderSchema);
