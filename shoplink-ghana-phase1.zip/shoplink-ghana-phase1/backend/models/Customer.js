const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema(
  {
    storeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Store',
      required: true,
      index: true,
    },
    name:  { type: String, trim: true, default: 'Unknown' },
    phone: { type: String, trim: true, default: '' },
    email: { type: String, trim: true, lowercase: true, default: '' },
    totalOrders: { type: Number, default: 0 },
    totalSpent:  { type: Number, default: 0 },
    notes: { type: String, trim: true, default: '' },
    lastOrderAt: { type: Date, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Customer', customerSchema);
