const mongoose = require('mongoose');

// Opens (and reuses) a single connection to MongoDB Atlas.
// server.js calls this once when the app boots.
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`MongoDB connection error: ${error.message}`);
    // If we can't reach the database there is no point staying alive.
    process.exit(1);
  }
};

module.exports = connectDB;
