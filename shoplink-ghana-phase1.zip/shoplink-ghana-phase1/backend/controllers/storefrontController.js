const Store = require('../models/Store');
const Product = require('../models/Product');
const Order = require('../models/Order');
const Customer = require('../models/Customer');
const mongoose = require('mongoose');
const asyncHandler = require('../utils/asyncHandler');

const getPublicStorefront = asyncHandler(async (req, res) => {
  const { storeId } = req.params;

  if (!mongoose.Types.ObjectId.isValid(storeId)) {
    res.status(400);
    throw new Error('Invalid store identifier');
  }

  const store = await Store.findById(storeId).select(
    'name description logo phone email address city country currency'
  );

  if (!store) {
    res.status(404);
    throw new Error('Store not found');
  }

  const products = await Product.find({
    storeId: store._id,
    inStock: true,
    quantity: { $gt: 0 },
    $or: [{ published: true }, { published: { $exists: false } }],
  }).sort({ createdAt: -1 });

  res.json({
    success: true,
    data: {
      store,
      count: products.length,
      products,
    },
  });
});

// @desc    Create an order from public storefront
// @route   POST /api/storefront/:storeId/orders
// @access  Public
const createPublicOrder = asyncHandler(async (req, res) => {
  const { storeId } = req.params;
  const { customerName, customerPhone, customerEmail, notes, items } = req.body;

  if (!mongoose.Types.ObjectId.isValid(storeId)) {
    res.status(400);
    throw new Error('Invalid store identifier');
  }

  const store = await Store.findById(storeId);
  if (!store) {
    res.status(404);
    throw new Error('Store not found');
  }

  if (!Array.isArray(items) || items.length === 0) {
    res.status(400);
    throw new Error('Order must contain at least one item');
  }

  if (!customerName || !customerPhone) {
    res.status(400);
    throw new Error('Customer name and phone number are required');
  }

  // Validate items & stock
  const orderItems = [];
  const productsToUpdate = [];

  for (const item of items) {
    if (!item.productId || !mongoose.Types.ObjectId.isValid(item.productId)) {
      res.status(400);
      throw new Error('Invalid product identifier in order items');
    }

    const qty = Math.max(1, parseInt(item.quantity, 10) || 1);
    const product = await Product.findOne({ _id: item.productId, storeId: store._id });

    if (!product) {
      res.status(404);
      throw new Error(`Product not found for ID: ${item.productId}`);
    }

    if (!product.inStock || product.quantity < qty) {
      res.status(400);
      throw new Error(`Insufficient stock for "${product.name}". Available: ${product.quantity}`);
    }

    orderItems.push({
      productId: product._id,
      name: product.name,
      price: product.price,
      quantity: qty,
    });

    productsToUpdate.push({ product, qty });
  }

  // Calculate total
  const total = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // Create order
  const order = await Order.create({
    storeId: store._id,
    customerName: customerName.trim(),
    customerPhone: customerPhone.trim(),
    customerEmail: (customerEmail || '').trim(),
    items: orderItems,
    total,
    status: 'pending',
    notes: (notes || '').trim(),
  });

  // Update stock quantities
  for (const { product, qty } of productsToUpdate) {
    product.quantity = Math.max(0, product.quantity - qty);
    if (product.quantity === 0) {
      product.inStock = false;
    }
    await product.save();
  }

  // Update or create Customer record
  if (customerPhone) {
    let customer = await Customer.findOne({
      storeId: store._id,
      phone: customerPhone.trim(),
    });

    if (customer) {
      customer.totalOrders += 1;
      customer.totalSpent += total;
      customer.lastOrderAt = new Date();
      if (customerName && (customer.name === 'Unknown' || !customer.name)) {
        customer.name = customerName.trim();
      }
      if (customerEmail && !customer.email) {
        customer.email = customerEmail.trim();
      }
      await customer.save();
    } else {
      await Customer.create({
        storeId: store._id,
        name: customerName.trim() || 'Unknown',
        phone: customerPhone.trim(),
        email: (customerEmail || '').trim(),
        totalOrders: 1,
        totalSpent: total,
        lastOrderAt: new Date(),
      });
    }
  }

  res.status(201).json({
    success: true,
    data: order,
  });
});

module.exports = { getPublicStorefront, createPublicOrder };

