const Customer = require('../models/Customer');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Get all customers for the logged in user's store
// @route   GET /api/customers
// @access  Private
const getCustomers = asyncHandler(async (req, res) => {
  if (!req.user.storeId) {
    res.status(400);
    throw new Error('User does not have an associated store');
  }

  const customers = await Customer.find({ storeId: req.user.storeId }).sort('-createdAt');
  res.json({ success: true, count: customers.length, data: customers });
});

// @desc    Get single customer
// @route   GET /api/customers/:id
// @access  Private
const getCustomerById = asyncHandler(async (req, res) => {
  const customer = await Customer.findById(req.params.id);

  if (!customer) {
    res.status(404);
    throw new Error('Customer not found');
  }

  if (customer.storeId.toString() !== req.user.storeId.toString()) {
    res.status(403);
    throw new Error('Not authorized to access this customer');
  }

  res.json({ success: true, data: customer });
});

// @desc    Create customer manually
// @route   POST /api/customers
// @access  Private
const createCustomer = asyncHandler(async (req, res) => {
  if (!req.user.storeId) {
    res.status(400);
    throw new Error('User does not have an associated store');
  }

  const { name, phone, email, notes } = req.body;

  const customer = await Customer.create({
    storeId: req.user.storeId,
    name,
    phone,
    email,
    notes
  });

  res.status(201).json({ success: true, data: customer });
});

// @desc    Update customer
// @route   PUT /api/customers/:id
// @access  Private
const updateCustomer = asyncHandler(async (req, res) => {
  let customer = await Customer.findById(req.params.id);

  if (!customer) {
    res.status(404);
    throw new Error('Customer not found');
  }

  if (customer.storeId.toString() !== req.user.storeId.toString()) {
    res.status(403);
    throw new Error('Not authorized to update this customer');
  }

  customer = await Customer.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.json({ success: true, data: customer });
});

// @desc    Delete customer
// @route   DELETE /api/customers/:id
// @access  Private
const deleteCustomer = asyncHandler(async (req, res) => {
  const customer = await Customer.findById(req.params.id);

  if (!customer) {
    res.status(404);
    throw new Error('Customer not found');
  }

  if (customer.storeId.toString() !== req.user.storeId.toString()) {
    res.status(403);
    throw new Error('Not authorized to delete this customer');
  }

  await customer.deleteOne();

  res.json({ success: true, message: 'Customer removed' });
});

module.exports = {
  getCustomers,
  getCustomerById,
  createCustomer,
  updateCustomer,
  deleteCustomer
};
