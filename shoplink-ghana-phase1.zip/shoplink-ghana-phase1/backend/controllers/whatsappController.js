const Store = require('../models/Store');
const Product = require('../models/Product');
const Order = require('../models/Order');
const Customer = require('../models/Customer');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Verify WhatsApp Webhook with Meta Cloud API
// @route   GET /api/whatsapp/webhook
// @access  Public
const verifyWebhook = (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  const expectedToken = process.env.WHATSAPP_VERIFY_TOKEN || 'shoplink_verify_secret';

  if (mode && token) {
    if (mode === 'subscribe' && token === expectedToken) {
      console.log('WhatsApp Webhook Verified successfully');
      return res.status(200).send(challenge);
    }
    return res.sendStatus(403);
  }
  res.sendStatus(400);
};

// @desc    Handle incoming WhatsApp messages from Meta
// @route   POST /api/whatsapp/webhook
// @access  Public
const handleWebhook = asyncHandler(async (req, res) => {
  const body = req.body;

  if (body.object === 'whatsapp_business_account') {
    if (
      body.entry &&
      body.entry[0].changes &&
      body.entry[0].changes[0].value.messages &&
      body.entry[0].changes[0].value.messages[0]
    ) {
      const message = body.entry[0].changes[0].value.messages[0];
      const fromPhone = message.from; // Customer's phone
      const messageText = message.text ? message.text.body : '';
      const phoneNumberId = body.entry[0].changes[0].value.metadata.phone_number_id;

      console.log(`Received WhatsApp message from ${fromPhone}: "${messageText}"`);

      // Find store by whatsappPhoneNumberId or default to first store in dev
      let store = await Store.findOne({ whatsappPhoneNumberId: phoneNumberId });
      if (!store) {
        store = await Store.findOne();
      }

      if (store) {
        // Track customer automatically
        let customer = await Customer.findOne({ storeId: store._id, phone: fromPhone });
        if (!customer) {
          customer = await Customer.create({
            storeId: store._id,
            phone: fromPhone,
            name: body.entry[0].changes[0].value.contacts?.[0]?.profile?.name || 'WhatsApp Customer',
            notes: 'Created via WhatsApp incoming chat'
          });
        }
      }
    }
    return res.status(200).send('EVENT_RECEIVED');
  }

  res.sendStatus(404);
});

// @desc    Get WhatsApp connection config for the current user's store
// @route   GET /api/whatsapp/config
// @access  Private
const getWhatsAppConfig = asyncHandler(async (req, res) => {
  const store = await Store.findById(req.user.storeId);
  if (!store) {
    res.status(404);
    throw new Error('Store not found');
  }

  res.json({
    success: true,
    data: {
      whatsappPhoneNumberId: store.whatsappPhoneNumberId || '',
      whatsappBusinessAccountId: store.whatsappBusinessAccountId || '',
      isConnected: Boolean(store.whatsappPhoneNumberId && store.whatsappBusinessAccountId),
      webhookUrl: `${req.protocol}://${req.get('host')}/api/whatsapp/webhook`,
      verifyToken: process.env.WHATSAPP_VERIFY_TOKEN || 'shoplink_verify_secret'
    }
  });
});

// @desc    Update WhatsApp credentials for the store
// @route   PUT /api/whatsapp/config
// @access  Private
const updateWhatsAppConfig = asyncHandler(async (req, res) => {
  const { whatsappPhoneNumberId, whatsappBusinessAccountId, whatsappAccessToken } = req.body;

  const updateFields = {
    whatsappPhoneNumberId: whatsappPhoneNumberId ? whatsappPhoneNumberId.trim() : '',
    whatsappBusinessAccountId: whatsappBusinessAccountId ? whatsappBusinessAccountId.trim() : ''
  };

  if (whatsappAccessToken) {
    updateFields.whatsappAccessToken = whatsappAccessToken.trim();
  }

  const store = await Store.findByIdAndUpdate(req.user.storeId, updateFields, { new: true });

  res.json({
    success: true,
    message: 'WhatsApp configuration saved',
    data: {
      whatsappPhoneNumberId: store.whatsappPhoneNumberId,
      whatsappBusinessAccountId: store.whatsappBusinessAccountId,
      isConnected: Boolean(store.whatsappPhoneNumberId && store.whatsappBusinessAccountId)
    }
  });
});

module.exports = {
  verifyWebhook,
  handleWebhook,
  getWhatsAppConfig,
  updateWhatsAppConfig
};
