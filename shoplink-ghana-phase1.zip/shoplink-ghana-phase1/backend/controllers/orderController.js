const Order = require('../models/Order');
const Customer = require('../models/Customer');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Get all orders for the logged in user's store
// @route   GET /api/orders
// @access  Private
const getOrders = asyncHandler(async (req, res) => {
  if (!req.user.storeId) {
    res.status(400);
    throw new Error('User does not have an associated store');
  }

  const orders = await Order.find({ storeId: req.user.storeId }).sort('-createdAt');
  res.json({ success: true, count: orders.length, data: orders });
});

// @desc    Get single order
// @route   GET /api/orders/:id
// @access  Private
const getOrderById = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);

  if (!order) {
    res.status(404);
    throw new Error('Order not found');
  }

  if (order.storeId.toString() !== req.user.storeId.toString()) {
    res.status(403);
    throw new Error('Not authorized to access this order');
  }

  res.json({ success: true, data: order });
});

// @desc    Create an order (manual or automated)
// @route   POST /api/orders
// @access  Private
const createOrder = asyncHandler(async (req, res) => {
  if (!req.user.storeId) {
    res.status(400);
    throw new Error('User does not have an associated store');
  }

  const { customerName, customerPhone, customerEmail, items, status, notes } = req.body;

  const order = await Order.create({
    storeId: req.user.storeId,
    customerName,
    customerPhone,
    customerEmail,
    items,
    status: status || 'pending',
    notes
  });

  // Automatically update or create customer record if phone is provided
  if (customerPhone) {
    let customer = await Customer.findOne({
      storeId: req.user.storeId,
      phone: customerPhone
    });

    if (customer) {
      customer.totalOrders += 1;
      customer.totalSpent += order.total;
      customer.lastOrderAt = new Date();
      if (customerName && customer.name === 'Unknown') {
        customer.name = customerName;
      }
      await customer.save();
    } else {
      await Customer.create({
        storeId: req.user.storeId,
        name: customerName || 'Unknown',
        phone: customerPhone,
        email: customerEmail || '',
        totalOrders: 1,
        totalSpent: order.total,
        lastOrderAt: new Date()
      });
    }
  }

  res.status(201).json({ success: true, data: order });
});

// @desc    Update order status
// @route   PUT /api/orders/:id/status
// @access  Private
const updateOrderStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  const order = await Order.findById(req.params.id);

  if (!order) {
    res.status(404);
    throw new Error('Order not found');
  }

  if (order.storeId.toString() !== req.user.storeId.toString()) {
    res.status(403);
    throw new Error('Not authorized to update this order');
  }

  order.status = status || order.status;
  await order.save();

  res.json({ success: true, data: order });
});

module.exports = {
  getOrders,
  getOrderById,
  createOrder,
  updateOrderStatus
};
