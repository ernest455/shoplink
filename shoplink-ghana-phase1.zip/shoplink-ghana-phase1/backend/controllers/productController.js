const Product = require('../models/Product');
const asyncHandler = require('../utils/asyncHandler');

const updateFields = [
  'name',
  'description',
  'price',
  'category',
  'images',
  'inStock',
  'quantity',
  'sku',
  'published',
];

const getProducts = asyncHandler(async (req, res) => {
  if (!req.user.storeId) {
    res.status(400);
    throw new Error('User does not have an associated store');
  }

  const products = await Product.find({ storeId: req.user.storeId }).sort({ createdAt: -1 });
  res.json({ success: true, count: products.length, data: products });
});

const createProduct = asyncHandler(async (req, res) => {
  if (!req.user.storeId) {
    res.status(400);
    throw new Error('User does not have an associated store');
  }

  const {
    name,
    price,
    description,
    category,
    quantity,
    inStock,
    images,
    sku,
    published,
  } = req.body;
  const normalizedQuantity = Number.isFinite(quantity) ? Math.max(0, Math.floor(quantity)) : 0;

  const product = await Product.create({
    storeId: req.user.storeId,
    name,
    price,
    description,
    category,
    quantity: normalizedQuantity,
    inStock: inStock === undefined ? normalizedQuantity > 0 : Boolean(inStock),
    images: Array.isArray(images) ? images : [],
    sku,
    published: published !== false,
  });

  res.status(201).json({ success: true, data: product });
});

const updateProduct = asyncHandler(async (req, res) => {
  const updates = {};

  updateFields.forEach((field) => {
    if (Object.prototype.hasOwnProperty.call(req.body, field)) {
      updates[field] = req.body[field];
    }
  });

  if (Object.prototype.hasOwnProperty.call(updates, 'quantity')) {
    updates.quantity = Math.max(0, Math.floor(updates.quantity));
  }

  if (
    Object.prototype.hasOwnProperty.call(updates, 'quantity') &&
    !Object.prototype.hasOwnProperty.call(updates, 'inStock')
  ) {
    updates.inStock = updates.quantity > 0;
  }

  const product = await Product.findOneAndUpdate(
    { _id: req.params.id, storeId: req.user.storeId },
    updates,
    { new: true, runValidators: true }
  );

  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }

  res.json({ success: true, data: product });
});

const deleteProduct = asyncHandler(async (req, res) => {
  const product = await Product.findOneAndDelete({
    _id: req.params.id,
    storeId: req.user.storeId,
  });

  if (!product) {
    res.status(404);
    throw new Error('Product not found');
  }

  res.json({ success: true, message: 'Product removed' });
});

module.exports = {
  getProducts,
  createProduct,
  updateProduct,
  deleteProduct,
};
