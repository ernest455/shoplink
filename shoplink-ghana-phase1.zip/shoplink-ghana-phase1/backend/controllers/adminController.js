const Store = require('../models/Store');
const User = require('../models/User');
const Product = require('../models/Product');
const Order = require('../models/Order');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Get all stores (Admin)
// @route   GET /api/admin/stores
// @access  Private/Admin
const getAllStores = asyncHandler(async (req, res) => {
  const stores = await Store.find({}).sort('-createdAt');

  // Enrich each store with product & order counts
  const storeData = await Promise.all(
    stores.map(async (store) => {
      const owner = await User.findOne({ storeId: store._id }).select('name email role status');
      const productCount = await Product.countDocuments({ storeId: store._id });
      const orderCount = await Order.countDocuments({ storeId: store._id });
      const orders = await Order.find({ storeId: store._id });
      const totalRevenue = orders.reduce((sum, o) => sum + (o.total || 0), 0);

      return {
        ...store.toObject(),
        ownerName: owner ? owner.name : 'Unknown Owner',
        ownerEmail: owner ? owner.email : 'No email',
        ownerStatus: owner ? owner.status : 'active',
        productCount,
        orderCount,
        totalRevenue,
      };
    })
  );

  res.json({ success: true, count: storeData.length, data: storeData });
});

// @desc    Update store status (Suspend / Activate)
// @route   PUT /api/admin/stores/:id/status
// @access  Private/Admin
const updateStoreStatus = asyncHandler(async (req, res) => {
  const { status, suspendedReason } = req.body;

  if (!['active', 'suspended', 'pending'].includes(status)) {
    res.status(400);
    throw new Error('Invalid store status');
  }

  const store = await Store.findById(req.params.id);
  if (!store) {
    res.status(404);
    throw new Error('Store not found');
  }

  store.status = status;
  if (suspendedReason !== undefined) {
    store.suspendedReason = suspendedReason.trim();
  }

  await store.save();
  res.json({ success: true, data: store });
});

// @desc    Get all registered users
// @route   GET /api/admin/users
// @access  Private/Admin
const getAllUsers = asyncHandler(async (req, res) => {
  const users = await User.find({}).populate('storeId', 'name').sort('-createdAt');
  res.json({ success: true, count: users.length, data: users });
});

// @desc    Update user status (Block / Unblock)
// @route   PUT /api/admin/users/:id/status
// @access  Private/Admin
const updateUserStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!['active', 'blocked'].includes(status)) {
    res.status(400);
    throw new Error('Invalid user status');
  }

  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  if (user._id.toString() === req.user._id.toString()) {
    res.status(400);
    throw new Error('You cannot block your own admin account');
  }

  user.status = status;
  await user.save();

  res.json({ success: true, data: user });
});

// @desc    Force reset user password
// @route   POST /api/admin/users/:id/reset-password
// @access  Private/Admin
const resetUserPasswordAdmin = asyncHandler(async (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) {
    res.status(400);
    throw new Error('Password must be at least 6 characters');
  }

  const user = await User.findById(req.params.id).select('+password');
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  user.password = newPassword; // pre-save hook will hash this
  await user.save();

  res.json({ success: true, message: `Password reset successfully for ${user.email}` });
});

// @desc    Get all products across stores
// @route   GET /api/admin/products
// @access  Private/Admin
const getAllProductsAdmin = asyncHandler(async (req, res) => {
  const products = await Product.find({}).populate('storeId', 'name city').sort('-createdAt');
  res.json({ success: true, count: products.length, data: products });
});

// @desc    Get all orders across stores
// @route   GET /api/admin/orders
// @access  Private/Admin
const getAllOrdersAdmin = asyncHandler(async (req, res) => {
  const orders = await Order.find({}).populate('storeId', 'name phone').sort('-createdAt');
  res.json({ success: true, count: orders.length, data: orders });
});

// @desc    Get platform-wide analytics & GMV
// @route   GET /api/admin/analytics
// @access  Private/Admin
const getPlatformAnalytics = asyncHandler(async (req, res) => {
  const totalStores = await Store.countDocuments({});
  const activeStores = await Store.countDocuments({ status: 'active' });
  const suspendedStores = await Store.countDocuments({ status: 'suspended' });
  const totalUsers = await User.countDocuments({});
  const totalProducts = await Product.countDocuments({});
  const totalOrders = await Order.countDocuments({});

  const allOrders = await Order.find({}).select('total status createdAt');
  const platformGMV = allOrders.reduce((sum, o) => sum + (o.total || 0), 0);

  // Category breakdown
  const products = await Product.find({}).select('category');
  const categoryCounts = {};
  products.forEach((p) => {
    const cat = p.category || 'General';
    categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;
  });

  // Status breakdown
  const orderStatusCounts = {
    pending: 0,
    confirmed: 0,
    processing: 0,
    shipped: 0,
    delivered: 0,
    cancelled: 0,
  };
  allOrders.forEach((o) => {
    if (orderStatusCounts[o.status] !== undefined) {
      orderStatusCounts[o.status] += 1;
    }
  });

  res.json({
    success: true,
    data: {
      metrics: {
        platformGMV,
        totalStores,
        activeStores,
        suspendedStores,
        totalUsers,
        totalProducts,
        totalOrders,
      },
      categories: categoryCounts,
      orderStatuses: orderStatusCounts,
    },
  });
});

module.exports = {
  getAllStores,
  updateStoreStatus,
  getAllUsers,
  updateUserStatus,
  resetUserPasswordAdmin,
  getAllProductsAdmin,
  getAllOrdersAdmin,
  getPlatformAnalytics,
};
