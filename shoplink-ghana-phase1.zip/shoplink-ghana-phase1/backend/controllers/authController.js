const asyncHandler = require('../utils/asyncHandler');
const User = require('../models/User');
const Store = require('../models/Store');
const generateToken = require('../utils/generateToken');

// @desc    Register a new business owner and create their store
// @route   POST /api/auth/register
// @access  Public
const registerUser = asyncHandler(async (req, res) => {
  const name = req.body.name ? req.body.name.trim() : '';
  const email = req.body.email ? req.body.email.trim() : '';
  const password = req.body.password || '';
  const storeName = req.body.storeName ? req.body.storeName.trim() : '';

  if (!name || !email || !password || !storeName) {
    res.status(400);
    throw new Error('Name, email, password and store name are all required');
  }

  if (password.length < 6) {
    res.status(400);
    throw new Error('Password must be at least 6 characters');
  }

  const existingUser = await User.findOne({ email: email.toLowerCase() });
  if (existingUser) {
    res.status(400);
    throw new Error('An account with that email already exists');
  }

  // Every business owner gets a store the moment they register -
  // this is what the "Create Store" step in the onboarding diagram means.
  const store = await Store.create({ name: storeName });

  let user;
  try {
    user = await User.create({
      name,
      email,
      password,
      role: 'owner',
      storeId: store._id,
    });
  } catch (error) {
    // Don't leave an orphaned store behind if the user record couldn't
    // be created (e.g. a duplicate-email race condition).
    await Store.findByIdAndDelete(store._id);
    throw error;
  }

  res.status(201).json({
    success: true,
    message: 'Account created successfully',
    data: {
      token: generateToken(user._id),
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
      store: {
        id: store._id,
        name: store.name,
        subscriptionPlan: store.subscriptionPlan,
        subscriptionStatus: store.subscriptionStatus,
      },
    },
  });
});

// @desc    Log in an existing user
// @route   POST /api/auth/login
// @access  Public
const loginUser = asyncHandler(async (req, res) => {
  const email = req.body.email ? req.body.email.trim() : '';
  const password = req.body.password || '';

  if (!email || !password) {
    res.status(400);
    throw new Error('Email and password are required');
  }

  // password has `select: false` on the schema, so we opt back in here
  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');

  if (!user || !(await user.comparePassword(password))) {
    res.status(401);
    throw new Error('Invalid email or password');
  }

  const store = user.storeId ? await Store.findById(user.storeId) : null;

  res.json({
    success: true,
    message: 'Login successful',
    data: {
      token: generateToken(user._id),
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
      store: store
        ? {
            id: store._id,
            name: store.name,
            subscriptionPlan: store.subscriptionPlan,
            subscriptionStatus: store.subscriptionStatus,
          }
        : null,
    },
  });
});

// @desc    Get the currently logged-in user (used to restore a session)
// @route   GET /api/auth/me
// @access  Private
const getMe = asyncHandler(async (req, res) => {
  const user = req.user;
  const store = user.storeId ? await Store.findById(user.storeId) : null;

  res.json({
    success: true,
    data: {
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
      store: store
        ? {
            id: store._id,
            name: store.name,
            subscriptionPlan: store.subscriptionPlan,
            subscriptionStatus: store.subscriptionStatus,
          }
        : null,
    },
  });
});

// @desc    Seed admin user (only for development)
// @route   POST /api/auth/seed-admin
// @access  Public (should be protected in prod)
const seedAdminUser = asyncHandler(async (req, res) => {
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@shoplink.gh';
  const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';

  const existing = await User.findOne({ email: adminEmail.toLowerCase() });
  if (existing) {
    return res.json({ success: true, message: 'Admin already exists', data: { email: existing.email } });
  }
  const store = await Store.create({ name: 'Admin Store' });
  const adminUser = await User.create({
    name: 'Admin',
    email: adminEmail,
    password: adminPassword,
    role: 'admin',
    storeId: store._id,
  });
  res.status(201).json({
    success: true,
    message: 'Admin created',
    data: {
      token: generateToken(adminUser._id),
      user: { id: adminUser._id, name: adminUser.name, email: adminUser.email, role: adminUser.role },
      store: { id: store._id, name: store.name },
    },
  });
});

// @desc    Admin utility – forcefully reset any user's password
// @route   POST /api/auth/reset-password
// @access  Admin only (protect + authorize('admin'))
const resetPassword = asyncHandler(async (req, res) => {
  const { email, newPassword } = req.body;
  if (!email || !newPassword) {
    res.status(400);
    throw new Error('email and newPassword are required');
  }
  if (newPassword.length < 6) {
    res.status(400);
    throw new Error('newPassword must be at least 6 characters');
  }
  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
  if (!user) {
    res.status(404);
    throw new Error('No user found with that email');
  }
  user.password = newPassword;  // pre-save hook will bcrypt this
  await user.save();
  res.json({ success: true, message: `Password reset for ${user.email}` });
});

module.exports = { registerUser, loginUser, getMe, seedAdminUser, resetPassword };
