const Store = require('../models/Store');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Get store profile
// @route   GET /api/store
// @access  Private
const getStoreProfile = asyncHandler(async (req, res) => {
  const store = await Store.findById(req.user.storeId);
  if (!store) {
    res.status(404);
    throw new Error('Store not found');
  }

  res.json({
    success: true,
    data: store
  });
});

// @desc    Update store profile
// @route   PUT /api/store
// @access  Private
const updateStoreProfile = asyncHandler(async (req, res) => {
  const { name, description, phone, email, address, city, currency, paystackPublicKey } = req.body;

  const store = await Store.findByIdAndUpdate(
    req.user.storeId,
    { name, description, phone, email, address, city, currency, paystackPublicKey },
    { new: true, runValidators: true }
  );

  res.json({
    success: true,
    message: 'Store settings updated successfully',
    data: store
  });
});

// @desc    Get subscription status
// @route   GET /api/store/subscription
// @access  Private
const getSubscription = asyncHandler(async (req, res) => {
  const store = await Store.findById(req.user.storeId);
  if (!store) {
    res.status(404);
    throw new Error('Store not found');
  }

  res.json({
    success: true,
    data: {
      plan: store.subscriptionPlan || 'starter',
      status: store.subscriptionStatus || 'trial',
      plans: [
        {
          id: 'starter',
          name: 'Starter',
          price: 99,
          currency: 'GHS',
          interval: 'month',
          features: ['Up to 50 Products', 'WhatsApp Order Automation', 'Standard Analytics', 'Email Support']
        },
        {
          id: 'business',
          name: 'Business',
          price: 199,
          currency: 'GHS',
          interval: 'month',
          popular: true,
          features: ['Unlimited Products', 'AI Sales Assistant (24/7)', 'Full Analytics & Reports', 'Paystack Payments', 'Priority Support']
        },
        {
          id: 'pro',
          name: 'Pro Enterprise',
          price: 399,
          currency: 'GHS',
          interval: 'month',
          features: ['Everything in Business', 'Custom AI Agent Training', 'Dedicated Account Manager', 'Multi-staff Access']
        }
      ]
    }
  });
});

// @desc    Change subscription plan
// @route   POST /api/store/subscription/upgrade
// @access  Private
const upgradeSubscription = asyncHandler(async (req, res) => {
  const { plan } = req.body;
  if (!['starter', 'business', 'pro'].includes(plan)) {
    res.status(400);
    throw new Error('Invalid subscription plan');
  }

  const store = await Store.findByIdAndUpdate(
    req.user.storeId,
    { subscriptionPlan: plan, subscriptionStatus: 'active' },
    { new: true }
  );

  res.json({
    success: true,
    message: `Plan upgraded to ${plan.toUpperCase()}!`,
    data: {
      plan: store.subscriptionPlan,
      status: store.subscriptionStatus
    }
  });
});

// @desc    Get all stores and users (Admin only)
// @route   GET /api/store/all
// @access  Private/Admin
const getAllStores = asyncHandler(async (req, res) => {
  const stores = await Store.find({}).sort({ createdAt: -1 });
  const users = await User.find({}).select('-password').sort({ createdAt: -1 });

  res.json({
    success: true,
    data: {
      totalStores: stores.length,
      totalUsers: users.length,
      stores,
      users
    }
  });
});

module.exports = {
  getStoreProfile,
  updateStoreProfile,
  getSubscription,
  upgradeSubscription,
  getAllStores
};

