const Order = require('../models/Order');
const Product = require('../models/Product');
const Customer = require('../models/Customer');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Get store analytics & sales summary
// @route   GET /api/analytics
// @access  Private
const getAnalytics = asyncHandler(async (req, res) => {
  if (!req.user.storeId) {
    res.status(400);
    throw new Error('User does not have an associated store');
  }

  const storeId = req.user.storeId;

  // Retrieve orders and products
  const orders = await Order.find({ storeId });
  const totalProducts = await Product.countDocuments({ storeId });
  const totalCustomers = await Customer.countDocuments({ storeId });

  // Compute key sales metrics
  const totalOrders = orders.length;
  const totalRevenue = orders.reduce((sum, o) => sum + (o.total || 0), 0);
  const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

  // Orders by status
  const ordersByStatus = {
    pending: 0,
    confirmed: 0,
    processing: 0,
    shipped: 0,
    delivered: 0,
    cancelled: 0,
  };

  orders.forEach(o => {
    if (ordersByStatus[o.status] !== undefined) {
      ordersByStatus[o.status]++;
    }
  });

  // Recent 7 days sales breakdown
  const last7Days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    d.setHours(0, 0, 0, 0);
    const nextDay = new Date(d);
    nextDay.setDate(d.getDate() + 1);

    const dayName = d.toLocaleDateString('en-GB', { weekday: 'short' });
    const dayOrders = orders.filter(o => {
      const orderDate = new Date(o.createdAt);
      return orderDate >= d && orderDate < nextDay;
    });

    const dayRevenue = dayOrders.reduce((sum, o) => sum + (o.total || 0), 0);

    last7Days.push({
      date: d.toISOString().split('T')[0],
      day: dayName,
      revenue: dayRevenue,
      count: dayOrders.length,
    });
  }

  // Top products calculation from orders item list
  const productSalesMap = {};
  orders.forEach(order => {
    (order.items || []).forEach(item => {
      if (!productSalesMap[item.name]) {
        productSalesMap[item.name] = { name: item.name, quantity: 0, revenue: 0 };
      }
      productSalesMap[item.name].quantity += item.quantity || 1;
      productSalesMap[item.name].revenue += (item.price || 0) * (item.quantity || 1);
    });
  });

  const topProducts = Object.values(productSalesMap)
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5);

  res.json({
    success: true,
    data: {
      metrics: {
        totalRevenue,
        totalOrders,
        averageOrderValue,
        totalProducts,
        totalCustomers,
      },
      ordersByStatus,
      dailySales: last7Days,
      topProducts,
    },
  });
});

module.exports = {
  getAnalytics,
};
