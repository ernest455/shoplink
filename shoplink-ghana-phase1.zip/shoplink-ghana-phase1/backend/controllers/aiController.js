const Store = require('../models/Store');
const Product = require('../models/Product');
const asyncHandler = require('../utils/asyncHandler');

// @desc    Get AI assistant settings
// @route   GET /api/ai/settings
// @access  Private
const getAISettings = asyncHandler(async (req, res) => {
  const store = await Store.findById(req.user.storeId);
  if (!store) {
    res.status(404);
    throw new Error('Store not found');
  }

  res.json({
    success: true,
    data: {
      aiEnabled: store.aiEnabled !== undefined ? store.aiEnabled : true,
      aiPersonality: store.aiPersonality || 'Friendly & Professional Ghanaian Sales Assistant',
      aiGreetingMessage: store.aiGreetingMessage || 'Hello! Welcome to our store. Feel free to ask about any of our products or place an order!'
    }
  });
});

// @desc    Update AI assistant settings
// @route   PUT /api/ai/settings
// @access  Private
const updateAISettings = asyncHandler(async (req, res) => {
  const { aiEnabled, aiPersonality, aiGreetingMessage } = req.body;

  const store = await Store.findByIdAndUpdate(
    req.user.storeId,
    { aiEnabled, aiPersonality, aiGreetingMessage },
    { new: true }
  );

  res.json({
    success: true,
    message: 'AI Assistant settings updated successfully',
    data: {
      aiEnabled: store.aiEnabled,
      aiPersonality: store.aiPersonality,
      aiGreetingMessage: store.aiGreetingMessage
    }
  });
});

// @desc    Test chat with store AI assistant
// @route   POST /api/ai/chat
// @access  Private
const chatWithAI = asyncHandler(async (req, res) => {
  const { message } = req.body;
  if (!message) {
    res.status(400);
    throw new Error('Please provide a message');
  }

  const store = await Store.findById(req.user.storeId);
  const products = await Product.find({ storeId: req.user.storeId });

  // Intelligent conversational matcher using catalogue
  const query = message.toLowerCase();

  // If user asks for greeting or hello
  if (query.includes('hi') || query.includes('hello') || query.includes('hey')) {
    return res.json({
      success: true,
      data: {
        reply: `${store.aiGreetingMessage || 'Hello! Welcome to ' + store.name} We have ${products.length} product(s) available right now.`
      }
    });
  }

  // Look for matching products in inventory
  const matched = products.filter(p =>
    query.includes(p.name.toLowerCase()) ||
    (p.category && query.includes(p.category.toLowerCase())) ||
    (p.description && query.includes(p.description.toLowerCase()))
  );

  if (matched.length > 0) {
    const itemsText = matched
      .slice(0, 3)
      .map(p => `• *${p.name}* — GH₵${p.price.toFixed(2)} (${p.quantity > 0 ? 'In Stock (' + p.quantity + ' left)' : 'Sold Out'})`)
      .join('\n');

    return res.json({
      success: true,
      data: {
        reply: `Here is what I found for you:\n\n${itemsText}\n\nWould you like me to reserve one or prepare your order?`
      }
    });
  }

  // Check for catalog or what do you sell
  if (query.includes('catalogue') || query.includes('catalog') || query.includes('sell') || query.includes('product') || query.includes('items') || query.includes('what do you have')) {
    if (products.length === 0) {
      return res.json({
        success: true,
        data: {
          reply: `Welcome to ${store.name}! We are currently restocking our inventory. Please check back soon!`
        }
      });
    }

    const sample = products.slice(0, 4).map(p => `• *${p.name}* at GH₵${p.price.toFixed(2)}`).join('\n');
    return res.json({
      success: true,
      data: {
        reply: `Here are some of our popular products at ${store.name}:\n\n${sample}\n\nLet me know if any of these catch your eye!`
      }
    });
  }

  // General helpful response
  res.json({
    success: true,
    data: {
      reply: `Thank you for your message! At ${store.name}, we're always happy to assist. You can ask me about our current products, prices, or how to order via WhatsApp.`
    }
  });
});

module.exports = {
  getAISettings,
  updateAISettings,
  chatWithAI
};
