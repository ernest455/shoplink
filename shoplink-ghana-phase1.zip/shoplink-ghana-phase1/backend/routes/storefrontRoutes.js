const express = require('express');
const { getPublicStorefront, createPublicOrder } = require('../controllers/storefrontController');
const { catalogLimiter } = require('../middleware/rateLimiter');

const router = express.Router();

router.get('/:storeId/products', catalogLimiter, getPublicStorefront);
router.post('/:storeId/orders', catalogLimiter, createPublicOrder);
router.post('/:storeId/order', catalogLimiter, createPublicOrder);

module.exports = router;


