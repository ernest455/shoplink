const express = require('express');
const {
  getStoreProfile,
  updateStoreProfile,
  getSubscription,
  upgradeSubscription,
  getAllStores
} = require('../controllers/storeController');
const { protect, authorize } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(protect);

router.get('/all', authorize('admin'), getAllStores);

router.route('/')
  .get(getStoreProfile)
  .put(updateStoreProfile);

router.get('/subscription', getSubscription);
router.post('/subscription/upgrade', upgradeSubscription);

module.exports = router;

