const express = require('express');
const { registerUser, loginUser, getMe, seedAdminUser, resetPassword } = require('../controllers/authController');
const { protect, authorize } = require('../middleware/authMiddleware');
const { authLimiter } = require('../middleware/rateLimiter');

const router = express.Router();

router.post('/register', authLimiter, registerUser);
router.post('/login', authLimiter, loginUser);
router.get('/me', protect, getMe);
router.post('/seed-admin', seedAdminUser);
router.post('/reset-password', protect, authorize('admin'), resetPassword);

module.exports = router;
