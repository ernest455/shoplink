const express = require('express');
const {
  getAllStores,
  updateStoreStatus,
  getAllUsers,
  updateUserStatus,
  resetUserPasswordAdmin,
  getAllProductsAdmin,
  getAllOrdersAdmin,
  getPlatformAnalytics,
} = require('../controllers/adminController');
const { protect, authorize } = require('../middleware/authMiddleware');

const router = express.Router();

// Require logged-in user with role 'admin' for all routes
router.use(protect);
router.use(authorize('admin'));

router.get('/stores', getAllStores);
router.put('/stores/:id/status', updateStoreStatus);

router.get('/users', getAllUsers);
router.put('/users/:id/status', updateUserStatus);
router.post('/users/:id/reset-password', resetUserPasswordAdmin);

router.get('/products', getAllProductsAdmin);
router.get('/orders', getAllOrdersAdmin);
router.get('/analytics', getPlatformAnalytics);

module.exports = router;
