const express = require('express');
const {
  getAISettings,
  updateAISettings,
  chatWithAI
} = require('../controllers/aiController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(protect);

router.get('/settings', getAISettings);
router.put('/settings', updateAISettings);
router.post('/chat', chatWithAI);

module.exports = router;
