const express = require('express');
const {
  verifyWebhook,
  handleWebhook,
  getWhatsAppConfig,
  updateWhatsAppConfig
} = require('../controllers/whatsappController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

// Webhook endpoints for Meta Cloud API (public)
router.get('/webhook', verifyWebhook);
router.post('/webhook', handleWebhook);

// Protected dashboard settings endpoints
router.get('/config', protect, getWhatsAppConfig);
router.put('/config', protect, updateWhatsAppConfig);

module.exports = router;
