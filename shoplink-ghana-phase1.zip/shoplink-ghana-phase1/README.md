# ShopLink Ghana

ShopLink Ghana is a SaaS platform that helps Ghanaian small and medium
businesses sell through WhatsApp — catalogues, orders, payments, customers
and (eventually) an AI sales assistant, all connected to a business's
WhatsApp Business account and managed from one web dashboard.

This repo is being built **in phases**. This README always reflects what's
actually working right now.

## Status: Phase 2 — Product catalogue

What's built and working:

- Express + MongoDB backend, connected via Mongoose
- `User`, `Store`, and `Product` models
- Register (creates a user **and** their store together) and Login, with
  JWT auth and bcrypt password hashing
- Auth middleware protecting private routes
- Private product management for store owners, including inventory,
  product images, and publish controls
- A public customer catalogue at
  `/storefront.html?store=<storeId>` with search, category filtering,
  stock status, and WhatsApp order links
- A vanilla HTML/CSS/JS frontend: register page, login page, dashboard,
  and product management shell

What's **not** built yet (coming in later phases, and clearly marked as
"coming soon" in the dashboard sidebar so nothing pretends to work before
it does): orders, customers, WhatsApp integration, the AI assistant,
Paystack payments, analytics, and the admin role.

## Tech stack

| Layer    | Choice                                              |
|----------|------------------------------------------------------|
| Frontend | HTML5, CSS3, vanilla JavaScript, `fetch`             |
| Backend  | Node.js, Express                                     |
| Database | MongoDB (Atlas) via Mongoose                         |
| Auth     | JWT + bcryptjs                                       |
| Security | helmet, cors, express-rate-limit                     |

No React, by design — see the project brief.

## Folder structure

```
shoplink-ghana/
├── backend/
│   ├── config/
│   │   └── db.js                 # Mongoose connection
│   ├── controllers/
│   │   ├── authController.js     # register / login / getMe
│   │   ├── productController.js  # private product CRUD
│   │   └── storefrontController.js # public catalogue
│   ├── middleware/
│   │   ├── authMiddleware.js     # protect + authorize
│   │   ├── errorHandler.js       # centralized error responses
│   │   └── rateLimiter.js        # brute-force protection on auth routes
│   ├── models/
│   │   ├── User.js
│   │   ├── Store.js
│   │   └── Product.js
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── productRoutes.js
│   │   └── storefrontRoutes.js
│   ├── utils/
│   │   ├── asyncHandler.js
│   │   └── generateToken.js
│   ├── .env.example
│   ├── .gitignore
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   ├── config.js              # points the frontend at the API
│   │   ├── api.js                 # fetch wrapper + session storage
│   │   ├── register.js
│   │   ├── login.js
│   │   ├── dashboard.js
│   │   ├── products.js
│   │   └── storefront.js
│   ├── register.html
│   ├── login.html
│   ├── dashboard.html
│   ├── products.html
│   └── storefront.html
├── docs/
│   └── database.md
└── README.md
```

## Prerequisites

- **Node.js 18+** and npm — check with `node -v` (download from
  [nodejs.org](https://nodejs.org) if you don't have it)
- A **free MongoDB Atlas account** — [mongodb.com/cloud/atlas/register](https://www.mongodb.com/cloud/atlas/register)
- A code editor (VS Code is fine) and a terminal

## Setup — step by step

### 1. Get a MongoDB connection string

1. Create a free account at MongoDB Atlas and create a new **free (M0)
   cluster**.
2. Under **Database Access**, create a database user with a username and
   password (save these — you'll need them).
3. Under **Network Access**, click **Add IP Address** → **Allow access
   from anywhere** (`0.0.0.0/0`) — fine for local development.
4. Click **Connect** on your cluster → **Drivers** → copy the connection
   string. It looks like:
   ```
   mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
5. Replace `<username>` and `<password>` with the database user you
   created, and add a database name before the `?`, e.g.
   `.../shoplink-ghana?retryWrites=true...`.

### 2. Install backend dependencies

In your terminal:

```bash
cd shoplink-ghana/backend
npm install
```

**What this does:** reads `package.json` and downloads Express, Mongoose,
bcryptjs, jsonwebtoken and the other listed packages into
`backend/node_modules`.
**Expected result:** a line like `added 140 packages in Xs` and no red
error text.

### 3. Create your `.env` file

Still inside `backend/`:

```bash
cp .env.example .env
```

**What this does:** copies the template so you have your own private
`.env` file (this file is git-ignored — it will never be committed).
Now open `.env` in your editor and fill in:

```
MONGO_URI=<the connection string from step 1>
JWT_SECRET=<any long random string>
```

To generate a strong `JWT_SECRET`, run:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Leave the WhatsApp / Paystack / AI variables empty for now — they're not
used until later phases.

### 4. Start the server

```bash
npm run dev
```

**What this does:** starts the Express server with `nodemon`, which
restarts automatically whenever you save a file.
**Expected result:**

```
MongoDB connected: cluster0-shard-00-01.xxxxx.mongodb.net
ShopLink Ghana API running on http://localhost:5000
```

If you see `MongoDB connection error`, double-check your `MONGO_URI`,
password, and that you allowed access from anywhere in step 1.3.

### 5. Open the app

Go to **http://localhost:5000/register.html** in your browser. The
backend serves the frontend directly, so there's nothing else to run.

## Testing Phase 1

### A. Through the browser

1. Open `http://localhost:5000/register.html`
2. Fill in your name, a business name, an email, and a password (6+
   characters) — submit
3. You should be redirected to `dashboard.html`, showing your name and
   store name, with a "Business account created ✅" item in the checklist
4. Click **Log out**, then log back in at `login.html` with the same
   email/password — you should land back on the dashboard
5. Try registering again with the **same email** — you should see
   "An account with that email already exists"
6. Try logging in with the wrong password — you should see "Invalid
   email or password"

### B. Directly against the API (useful for debugging)

With the server running, in a second terminal:

```bash
# Register
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Ama Owusu","email":"ama@example.com","password":"secret123","storeName":"Ama'\''s Boutique"}'
```

You should get back `"success": true` and a `token`. Copy that token and
use it here:

```bash
# Get the logged-in user (replace YOUR_TOKEN)
curl http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer YOUR_TOKEN"
```

```bash
# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"ama@example.com","password":"secret123"}'
```

```bash
# Calling /me with no token should fail with 401
curl http://localhost:5000/api/auth/me
```

If all of the above behave as described, Phase 1 is working correctly.

## Environment variables

| Variable                  | Used for                                   | Required in Phase 1 |
|----------------------------|---------------------------------------------|:---:|
| `NODE_ENV`                 | Toggles request logging                     | ✅ |
| `PORT`                     | Port the API listens on                     | ✅ |
| `MONGO_URI`                 | MongoDB Atlas connection string             | ✅ |
| `JWT_SECRET`                | Signs/verifies login tokens                 | ✅ |
| `JWT_EXPIRES_IN`            | How long a login session lasts              | ✅ |
| `FRONTEND_URL`              | CORS allow-list                             | ✅ |
| `WHATSAPP_ACCESS_TOKEN`     | Meta WhatsApp Cloud API                     | Phase 3 |
| `WHATSAPP_PHONE_NUMBER_ID`  | Meta WhatsApp Cloud API                     | Phase 3 |
| `WHATSAPP_VERIFY_TOKEN`     | WhatsApp webhook verification               | Phase 3 |
| `PAYSTACK_SECRET_KEY`       | Server-side payment verification            | Phase 5 |
| `PAYSTACK_PUBLIC_KEY`       | Client-side Paystack checkout               | Phase 5 |
| `AI_API_KEY`                | AI sales assistant                          | Phase 4 |

## Security already in place

- Passwords hashed with bcrypt, never stored or returned in plain text
- Passwords and WhatsApp secrets use Mongoose `select: false` so they're
  excluded from every query by default
- JWT-protected private routes via the `protect` middleware
- Rate limiting on `/api/auth/*` to slow down brute-force attempts
- `helmet` for standard security headers, `cors` scoped to `FRONTEND_URL`
- Centralized error handling — no stack traces or internals leak to the
  client
- Nothing secret is ever hardcoded — everything sensitive lives in `.env`,
  which is git-ignored

## Roadmap

| Phase | Focus |
|---|---|
| 1 ✅ | Foundation, auth, store creation |
| 2 | Product management (CRUD, stock, images) |
| 3 | WhatsApp Cloud API integration + conversation state machine |
| 4 | AI sales assistant |
| 5 | Paystack payments + order flow |
| 6 | Analytics, subscriptions, admin role, deployment |

We'll confirm Phase 1 is fully working for you before starting Phase 2.

## Troubleshooting

- **`MongoDB connection error`** — check `MONGO_URI` for typos, confirm
  the database user's password doesn't contain characters that need
  URL-encoding (e.g. `@` → `%40`), and confirm Network Access allows your
  IP.
- **`EADDRINUSE` / port 5000 already in use** — another process is using
  that port. Either stop it, or change `PORT` in `.env`.
- **CORS error in the browser console** — make sure `FRONTEND_URL` in
  `.env` matches the URL you're opening the app from.
- **`jwt malformed` / 401 on every request** — your token expired or
  wasn't saved; log out and log back in.
