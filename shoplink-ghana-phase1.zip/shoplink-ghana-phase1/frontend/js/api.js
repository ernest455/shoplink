// ── api.js ─────────────────────────────────────────────────
// Shared fetch wrapper + session helpers.
// Loaded on every page after config.js.

const TOKEN_KEY = 'shoplink_token';
const USER_KEY  = 'shoplink_user';
const STORE_KEY = 'shoplink_store';

// ── Session helpers ──────────────────────────────────────────
function saveSession({ token, user, store }) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  if (user)  localStorage.setItem(USER_KEY,  JSON.stringify(user));
  if (store) localStorage.setItem(STORE_KEY, JSON.stringify(store));
}

function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

function getStoredUser() {
  const raw = localStorage.getItem(USER_KEY);
  try { return raw ? JSON.parse(raw) : null; } catch { return null; }
}

function getStoredStore() {
  const raw = localStorage.getItem(STORE_KEY);
  try { return raw ? JSON.parse(raw) : null; } catch { return null; }
}

function clearSession() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  localStorage.removeItem(STORE_KEY);
}

// ── Generic fetch wrapper ────────────────────────────────────
async function apiRequest(endpoint, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  let response;
  try {
    response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (_networkError) {
    throw new Error('Cannot reach the server. Please check that the backend is running.');
  }

  let data;
  try {
    data = await response.json();
  } catch {
    data = {};
  }

  if (!response.ok || data.success === false) {
    throw new Error(data.message || `Request failed (${response.status}). Please try again.`);
  }

  return data;
}

// ── Toast notifications ──────────────────────────────────────
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ── Form error helper ────────────────────────────────────────
function showError(boxId, message) {
  const box = document.getElementById(boxId);
  if (!box) return;
  box.textContent = message;
  box.classList.add('visible');
}

function clearError(boxId) {
  const box = document.getElementById(boxId);
  if (!box) return;
  box.textContent = '';
  box.classList.remove('visible');
}

// ── Button loading state ─────────────────────────────────────
function setButtonLoading(btnId, loading) {
  const btn = document.getElementById(btnId);
  if (!btn) return;
  if (loading) {
    btn.classList.add('loading');
    btn.disabled = true;
  } else {
    btn.classList.remove('loading');
    btn.disabled = false;
  }
}
