document.addEventListener('DOMContentLoaded', async () => {
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  const cachedUser = getStoredUser();
  if (cachedUser) {
    if (cachedUser.role !== 'admin') {
      alert('Access Restricted: Only Platform Admins can view the Admin Console.');
      window.location.replace('dashboard.html');
      return;
    }

    document.getElementById('sidebar-user-name').textContent = cachedUser.name || 'Admin';
    document.getElementById('sidebar-avatar').textContent = (cachedUser.name || 'A').slice(0, 2).toUpperCase();
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

  // Tab switching
  const tabs = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tabContents.forEach(c => {
        c.classList.remove('active');
        c.style.display = 'none';
      });

      tab.classList.add('active');
      const target = document.getElementById(tab.dataset.tab);
      if (target) {
        target.classList.add('active');
        target.style.display = 'block';
      }
    });
  });

  // Modals
  const suspendModal = document.getElementById('suspend-modal');
  const suspendForm = document.getElementById('suspend-form');
  const suspendClose = document.getElementById('suspend-modal-close');
  const suspendCancel = document.getElementById('suspend-cancel-btn');

  const resetModal = document.getElementById('reset-modal');
  const resetForm = document.getElementById('reset-form');
  const resetClose = document.getElementById('reset-modal-close');
  const resetCancel = document.getElementById('reset-cancel-btn');

  function closeModals() {
    suspendModal.classList.remove('active');
    resetModal.classList.remove('active');
  }

  suspendClose.addEventListener('click', closeModals);
  suspendCancel.addEventListener('click', closeModals);
  resetClose.addEventListener('click', closeModals);
  resetCancel.addEventListener('click', closeModals);

  // Helper formatting
  function formatPrice(val) {
    const num = Number(val) || 0;
    return `GH₵${num.toFixed(2)}`;
  }

  // Load Platform Analytics
  async function loadAnalytics() {
    try {
      const res = await apiRequest('/admin/analytics');
      const metrics = res.data.metrics;

      document.getElementById('metric-gmv').textContent = formatPrice(metrics.platformGMV);
      document.getElementById('metric-stores').textContent = metrics.totalStores;
      document.getElementById('metric-users').textContent = metrics.totalUsers;
      document.getElementById('metric-orders').textContent = metrics.totalOrders;

      document.getElementById('stores-count-badge').textContent = metrics.totalStores;
      document.getElementById('users-count-badge').textContent = metrics.totalUsers;
      document.getElementById('products-count-badge').textContent = metrics.totalProducts;
      document.getElementById('orders-count-badge').textContent = metrics.totalOrders;
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  // Load Stores
  async function loadStores() {
    try {
      const res = await apiRequest('/admin/stores');
      const stores = res.data || [];
      const tbody = document.getElementById('stores-tbody');
      tbody.replaceChildren();

      stores.forEach(store => {
        const tr = document.createElement('tr');
        const isSuspended = store.status === 'suspended';

        tr.innerHTML = `
          <td><strong>${store.name}</strong></td>
          <td>${store.ownerName}<br/><small class="text-muted">${store.ownerEmail}</small></td>
          <td>${[store.city, store.country].filter(Boolean).join(', ') || 'Ghana'}</td>
          <td>${store.productCount}</td>
          <td>${store.orderCount}</td>
          <td>${formatPrice(store.totalRevenue)}</td>
          <td>
            <span class="status-badge ${isSuspended ? 'out-of-stock' : 'in-stock'}">
              ${isSuspended ? 'Suspended' : 'Active'}
            </span>
          </td>
          <td>
            ${isSuspended 
              ? `<button class="btn btn-outline activate-store-btn" data-id="${store._id}" style="padding: 0.3rem 0.6rem; font-size: 0.8rem; border-color: var(--success); color: var(--success);">Re-activate</button>`
              : `<button class="btn btn-outline suspend-store-btn" data-id="${store._id}" data-name="${store.name}" style="padding: 0.3rem 0.6rem; font-size: 0.8rem; color: var(--error);">Suspend</button>`
            }
          </td>
        `;
        tbody.appendChild(tr);
      });

      // Bind actions
      document.querySelectorAll('.suspend-store-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          document.getElementById('suspend-store-id').value = btn.dataset.id;
          document.getElementById('suspend-store-name').textContent = `Store: ${btn.dataset.name}`;
          document.getElementById('suspend-reason').value = '';
          suspendModal.classList.add('active');
        });
      });

      document.querySelectorAll('.activate-store-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          if (!confirm('Are you sure you want to re-activate this store?')) return;
          try {
            await apiRequest(`/admin/stores/${btn.dataset.id}/status`, {
              method: 'PUT',
              body: { status: 'active' },
            });
            showToast('Store re-activated successfully!');
            await Promise.all([loadAnalytics(), loadStores()]);
          } catch (err) {
            showToast(err.message, 'error');
          }
        });
      });

    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  // Suspend Form Submit
  suspendForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const storeId = document.getElementById('suspend-store-id').value;
    const reason = document.getElementById('suspend-reason').value.trim();

    try {
      await apiRequest(`/admin/stores/${storeId}/status`, {
        method: 'PUT',
        body: { status: 'suspended', suspendedReason: reason },
      });
      showToast('Store suspended successfully');
      closeModals();
      await Promise.all([loadAnalytics(), loadStores()]);
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Load Users
  async function loadUsers() {
    try {
      const res = await apiRequest('/admin/users');
      const users = res.data || [];
      const tbody = document.getElementById('users-tbody');
      tbody.replaceChildren();

      users.forEach(user => {
        const tr = document.createElement('tr');
        const isBlocked = user.status === 'blocked';
        const dateStr = new Date(user.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

        tr.innerHTML = `
          <td><strong>${user.name}</strong></td>
          <td>${user.email}</td>
          <td>
            <span class="role-badge ${user.role === 'admin' ? 'role-badge-admin' : 'role-badge-owner'}">
              ${user.role === 'admin' ? '🛡️ Platform Admin' : '👑 Store Owner'}
            </span>
          </td>
          <td>${user.storeId?.name || 'No Store'}</td>
          <td>
            <span class="status-badge ${isBlocked ? 'out-of-stock' : 'in-stock'}">
              ${isBlocked ? 'Blocked' : 'Active'}
            </span>
          </td>
          <td>${dateStr}</td>
          <td>
            ${isBlocked 
              ? `<button class="btn btn-outline unblock-user-btn" data-id="${user._id}" style="padding: 0.3rem 0.6rem; font-size: 0.8rem; border-color: var(--success); color: var(--success); margin-right: 0.25rem;">Unblock</button>`
              : `<button class="btn btn-outline block-user-btn" data-id="${user._id}" style="padding: 0.3rem 0.6rem; font-size: 0.8rem; color: var(--error); margin-right: 0.25rem;">Block</button>`
            }
            <button class="btn btn-ghost reset-pass-btn" data-id="${user._id}" data-email="${user.email}" style="padding: 0.3rem 0.6rem; font-size: 0.8rem;">Reset Password</button>
          </td>
        `;
        tbody.appendChild(tr);
      });

      document.querySelectorAll('.block-user-btn').forEach(btn => {
        btn.addEventListener('click', () => toggleUserBlock(btn.dataset.id, 'blocked'));
      });

      document.querySelectorAll('.unblock-user-btn').forEach(btn => {
        btn.addEventListener('click', () => toggleUserBlock(btn.dataset.id, 'active'));
      });

      document.querySelectorAll('.reset-pass-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          document.getElementById('reset-user-id').value = btn.dataset.id;
          document.getElementById('reset-user-email').textContent = `User: ${btn.dataset.email}`;
          document.getElementById('reset-new-pass').value = '';
          resetModal.classList.add('active');
        });
      });

    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  async function toggleUserBlock(userId, newStatus) {
    if (!confirm(`Are you sure you want to ${newStatus === 'blocked' ? 'block' : 'unblock'} this user?`)) return;
    try {
      await apiRequest(`/admin/users/${userId}/status`, {
        method: 'PUT',
        body: { status: newStatus },
      });
      showToast(`User ${newStatus === 'blocked' ? 'blocked' : 'unblocked'} successfully`);
      await loadUsers();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  // Reset Password Submit
  resetForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const userId = document.getElementById('reset-user-id').value;
    const newPassword = document.getElementById('reset-new-pass').value;

    try {
      await apiRequest(`/admin/users/${userId}/reset-password`, {
        method: 'POST',
        body: { newPassword },
      });
      showToast('Password reset successfully!');
      closeModals();
    } catch (err) {
      showToast(err.message, 'error');
    }
  });

  // Load All Products
  async function loadProducts() {
    try {
      const res = await apiRequest('/admin/products');
      const products = res.data || [];
      const tbody = document.getElementById('admin-products-tbody');
      tbody.replaceChildren();

      products.forEach(p => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td><strong>${p.name}</strong></td>
          <td>${p.storeId?.name || 'Unknown Store'}</td>
          <td>${p.category || 'General'}</td>
          <td>${formatPrice(p.price)}</td>
          <td>${p.quantity}</td>
          <td>
            <span class="status-badge ${p.inStock && p.quantity > 0 ? 'in-stock' : 'out-of-stock'}">
              ${p.inStock && p.quantity > 0 ? 'In Stock' : 'Out of Stock'}
            </span>
          </td>
        `;
        tbody.appendChild(tr);
      });
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  // Load All Orders
  async function loadOrders() {
    try {
      const res = await apiRequest('/admin/orders');
      const orders = res.data || [];
      const tbody = document.getElementById('admin-orders-tbody');
      tbody.replaceChildren();

      orders.forEach(o => {
        const tr = document.createElement('tr');
        const dateStr = new Date(o.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

        tr.innerHTML = `
          <td><strong>${o.orderNumber || '—'}</strong></td>
          <td>${o.storeId?.name || 'Unknown Store'}</td>
          <td>${o.customerName || 'Walk-in'}</td>
          <td>${o.customerPhone || '—'}</td>
          <td>${formatPrice(o.total)}</td>
          <td><span class="status-badge ${o.status}">${o.status}</span></td>
          <td>${dateStr}</td>
        `;
        tbody.appendChild(tr);
      });
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  async function loadAllData() {
    await Promise.all([
      loadAnalytics(),
      loadStores(),
      loadUsers(),
      loadProducts(),
      loadOrders(),
    ]);
  }

  document.getElementById('refresh-admin-btn').addEventListener('click', () => {
    loadAllData();
    showToast('Admin data refreshed!');
  });

  await loadAllData();
});
