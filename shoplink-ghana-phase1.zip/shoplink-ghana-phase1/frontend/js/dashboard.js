// ── dashboard.js ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {

  // ── Route guard: must be logged in ──────────────────────────
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  // ── Helper: set avatar initials ──────────────────────────────
  function getInitials(name) {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    return parts.length >= 2
      ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
      : name.slice(0, 2).toUpperCase();
  }

  // ── Helper: format role badge HTML ───────────────────────────
  function formatRoleBadge(role) {
    if (role === 'admin') {
      return `<span class="role-badge role-badge-admin">🛡️ Platform Admin</span>`;
    }
    return `<span class="role-badge role-badge-owner">👑 Store Owner</span>`;
  }

  // ── Populate from local cache first (instant render) ─────────
  const cachedUser  = getStoredUser();
  const cachedStore = getStoredStore();

  if (cachedUser) {
    const firstName = cachedUser.name ? cachedUser.name.split(' ')[0] : 'there';
    document.getElementById('greeting-name').textContent    = firstName;
    document.getElementById('sidebar-user-name').textContent = cachedUser.name || '—';
    document.getElementById('sidebar-user-role').innerHTML   = formatRoleBadge(cachedUser.role);
    document.getElementById('sidebar-avatar').textContent   = getInitials(cachedUser.name);
    
    if (cachedUser.role === 'admin') {
      document.getElementById('admin-console-container').style.display = 'block';
      document.getElementById('owner-console-container').style.display = 'none';
      document.getElementById('plan-pill').textContent = 'Superadmin';
      document.getElementById('plan-pill').style.background = 'rgba(124, 58, 237, 0.15)';
      document.getElementById('plan-pill').style.color = '#6d28d9';
    }
  }

  if (cachedStore && cachedUser?.role !== 'admin') {
    document.getElementById('store-name').textContent      = cachedStore.name || 'your store';
    document.getElementById('store-card-name').textContent = cachedStore.name || 'Your Store';
    document.getElementById('plan-pill').textContent       = `${cachedStore.subscriptionPlan || 'starter'} plan`;
  }

  // ── Refresh from API (authoritative) ─────────────────────────
  try {
    const { data } = await apiRequest('/auth/me');
    const { user, store } = data;

    // Save fresh data to local storage
    saveSession({ token: getToken(), user, store });

    // Populate user info
    const firstName = user && user.name ? user.name.split(' ')[0] : 'there';
    document.getElementById('greeting-name').textContent    = firstName;
    document.getElementById('sidebar-user-name').textContent = user.name || '—';
    document.getElementById('sidebar-user-role').innerHTML   = formatRoleBadge(user.role);
    document.getElementById('sidebar-avatar').textContent   = getInitials(user.name);

    if (user.role === 'admin') {
      // ══════════════════════════════════════════════════════════
      // PLATFORM ADMIN DASHBOARD VIEW
      // ══════════════════════════════════════════════════════════
      document.getElementById('admin-console-container').style.display = 'block';
      document.getElementById('owner-console-container').style.display = 'none';
      document.getElementById('plan-pill').textContent = 'Superadmin';
      document.getElementById('plan-pill').style.background = 'rgba(124, 58, 237, 0.15)';
      document.getElementById('plan-pill').style.color = '#6d28d9';

      loadAdminDashboardData();
    } else {
      // ══════════════════════════════════════════════════════════
      // STORE OWNER DASHBOARD VIEW
      // ══════════════════════════════════════════════════════════
      document.getElementById('admin-console-container').style.display = 'none';
      document.getElementById('owner-console-container').style.display = 'block';

      if (store) {
        document.getElementById('store-name').textContent      = store.name || 'your store';
        document.getElementById('store-card-name').textContent = store.name || 'Your Store';
        document.getElementById('store-card-meta').textContent =
          `${store.country || 'Ghana'} · ${store.currency || 'GHS'} · ${store.subscriptionStatus || 'trial'}`;
        document.getElementById('plan-pill').textContent =
          `${store.subscriptionPlan || 'starter'} plan`;
      }

      // Fetch Store Owner live counts & sales
      try {
        const [prodRes, orderRes] = await Promise.all([
          apiRequest('/products'),
          apiRequest('/orders')
        ]);

        const products = prodRes.data || [];
        const orders = orderRes.data || [];

        const prodEl = document.getElementById('stat-products');
        if (prodEl) prodEl.textContent = products.length;

        const checklistProd = document.getElementById('checklist-products');
        if (checklistProd && products.length > 0) {
          checklistProd.classList.add('done');
        }

        const orderEl = document.getElementById('stat-orders');
        if (orderEl) orderEl.textContent = orders.length;

        const totalSales = orders.reduce((sum, o) => sum + (o.total || 0), 0);
        const salesEl = document.getElementById('stat-sales');
        if (salesEl) salesEl.textContent = `GH₵${totalSales.toFixed(2)}`;

        if (orders.length > 0) {
          const salesTrend = document.getElementById('stat-sales-trend');
          if (salesTrend) salesTrend.textContent = `${orders.length} order(s) processed`;
        }
      } catch (statsErr) {
        console.error('Error loading store stats:', statsErr);
      }
    }

  } catch (err) {
    // Token expired or invalid — sign out
    clearSession();
    window.location.replace('login.html');
    return;
  }

  // ── Admin Dashboard Functions ─────────────────────────────────
  async function loadAdminDashboardData() {
    try {
      const res = await apiRequest('/store/all');
      const { totalStores, totalUsers, stores, users } = res.data;

      document.getElementById('admin-stat-stores').textContent = totalStores || 0;
      document.getElementById('admin-stat-users').textContent = totalUsers || 0;

      const tbody = document.getElementById('admin-stores-tbody');
      if (!stores || stores.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="6" style="text-align:center; padding: 2rem; color: var(--text-muted);">
              No stores registered on the platform yet.
            </td>
          </tr>
        `;
        return;
      }

      // Create lookup map of user by storeId
      const userByStore = {};
      users.forEach(u => {
        if (u.storeId) userByStore[u.storeId] = u;
      });

      tbody.innerHTML = stores.map(st => {
        const owner = userByStore[st._id] || users.find(u => u._id === st.ownerId) || { name: 'Owner', email: st.email || 'N/A', role: 'owner' };
        const plan = st.subscriptionPlan || 'starter';
        const planClass = `plan-badge-${plan}`;

        return `
          <tr>
            <td>
              <strong>${st.name}</strong>
              <div style="font-size:0.75rem; color:var(--text-muted);">${st.country || 'Ghana'} · ${st.currency || 'GHS'}</div>
            </td>
            <td>
              <div>${owner.name}</div>
              <div style="font-size:0.75rem; color:var(--text-secondary);">${owner.email}</div>
            </td>
            <td>${formatRoleBadge(owner.role || 'owner')}</td>
            <td><span class="plan-badge-pill ${planClass}">${plan.toUpperCase()}</span></td>
            <td><span class="tag" style="background:var(--success-bg); color:var(--success); font-size:0.75rem;">${st.subscriptionStatus || 'active'}</span></td>
            <td>
              <button class="btn btn-outline reset-user-btn" data-email="${owner.email}" style="padding:0.25rem 0.6rem; font-size:0.75rem;">
                🔑 Reset Password
              </button>
            </td>
          </tr>
        `;
      }).join('');

      // Attach reset button handlers in table
      document.querySelectorAll('.reset-user-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const email = btn.getAttribute('data-email');
          document.getElementById('reset-user-email').value = email;
          document.getElementById('reset-password-modal').style.display = 'flex';
        });
      });

    } catch (adminErr) {
      showToast(adminErr.message || 'Failed to load platform admin data', 'error');
    }
  }

  // ── Password Reset Modal Event Listeners ───────────────────────
  const resetModal = document.getElementById('reset-password-modal');
  const openResetBtn = document.getElementById('open-reset-modal-btn');
  const closeResetBtn = document.getElementById('close-reset-modal-btn');
  const cancelResetBtn = document.getElementById('cancel-reset-modal-btn');
  const resetForm = document.getElementById('reset-password-form');

  if (openResetBtn) {
    openResetBtn.addEventListener('click', () => {
      resetModal.style.display = 'flex';
    });
  }

  const closeModal = () => { resetModal.style.display = 'none'; };
  if (closeResetBtn) closeResetBtn.addEventListener('click', closeModal);
  if (cancelResetBtn) cancelResetBtn.addEventListener('click', closeModal);

  if (resetForm) {
    resetForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('reset-user-email').value.trim();
      const newPassword = document.getElementById('reset-new-password').value;

      try {
        const res = await apiRequest('/auth/reset-password', {
          method: 'POST',
          body: { email, newPassword }
        });
        showToast(res.message || `Password reset for ${email} successfully!`);
        closeModal();
        resetForm.reset();
      } catch (err) {
        showToast(err.message, 'error');
      }
    });
  }

  // ── Logout ────────────────────────────────────────────────────
  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

});

