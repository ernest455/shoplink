document.addEventListener('DOMContentLoaded', async () => {
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  const cachedUser = getStoredUser();
  if (cachedUser) {
    document.getElementById('sidebar-user-name').textContent = cachedUser.name || '—';
    document.getElementById('sidebar-user-role').textContent = cachedUser.role || '—';
    const initials = cachedUser.name
      ? cachedUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
      : '?';
    document.getElementById('sidebar-avatar').textContent = initials;
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

  const form = document.getElementById('settings-form');

  async function loadStore() {
    try {
      const res = await apiRequest('/store');
      const s = res.data;

      document.getElementById('store-name-input').value = s.name || '';
      document.getElementById('store-desc-input').value = s.description || '';
      document.getElementById('store-phone-input').value = s.phone || '';
      document.getElementById('store-email-input').value = s.email || '';
      document.getElementById('store-address-input').value = s.address || '';
      document.getElementById('store-city-input').value = s.city || '';
      document.getElementById('store-currency-select').value = s.currency || 'GHS';
      document.getElementById('paystack-public-key').value = s.paystackPublicKey || '';
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    setButtonLoading('save-settings-btn', true);

    const payload = {
      name: document.getElementById('store-name-input').value.trim(),
      description: document.getElementById('store-desc-input').value.trim(),
      phone: document.getElementById('store-phone-input').value.trim(),
      email: document.getElementById('store-email-input').value.trim(),
      address: document.getElementById('store-address-input').value.trim(),
      city: document.getElementById('store-city-input').value.trim(),
      currency: document.getElementById('store-currency-select').value,
      paystackPublicKey: document.getElementById('paystack-public-key').value.trim()
    };

    try {
      const res = await apiRequest('/store', {
        method: 'PUT',
        body: payload
      });
      showToast('Settings saved successfully!');
      // Update store cache
      const storedStore = getStoredStore() || {};
      saveSession({ token: getToken(), user: getStoredUser(), store: { ...storedStore, name: payload.name } });
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setButtonLoading('save-settings-btn', false);
    }
  });

  loadStore();
});
