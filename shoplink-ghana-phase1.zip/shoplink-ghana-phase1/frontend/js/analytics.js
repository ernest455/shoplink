document.addEventListener('DOMContentLoaded', async () => {
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  const cachedUser = getStoredUser();
  if (cachedUser) {
    document.getElementById('sidebar-user-name').textContent = cachedUser.name || '—';
    const roleHtml = cachedUser.role === 'admin' 
      ? `<span class="role-badge role-badge-admin">🛡️ Platform Admin</span>` 
      : `<span class="role-badge role-badge-owner">👑 Store Owner</span>`;
    document.getElementById('sidebar-user-role').innerHTML = roleHtml;
    const initials = cachedUser.name
      ? cachedUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
      : '?';
    document.getElementById('sidebar-avatar').textContent = initials;
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

  async function loadAnalytics() {
    try {
      const res = await apiRequest('/analytics');
      const { dailySales, topProducts, ordersByStatus } = res.data;

      renderChart(dailySales || []);
      renderTopProducts(topProducts || []);
      renderFulfillment(ordersByStatus || {});
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function renderChart(days) {
    const chart = document.getElementById('revenue-chart');
    chart.innerHTML = '';

    const maxRev = Math.max(...days.map(d => d.revenue), 10);

    days.forEach(d => {
      const col = document.createElement('div');
      col.className = 'bar-col';
      const heightPercent = Math.max(Math.round((d.revenue / maxRev) * 100), 4);

      col.innerHTML = `
        <span class="bar-value">${d.revenue > 0 ? 'GH₵' + d.revenue.toFixed(0) : '0'}</span>
        <div class="bar" style="height: ${heightPercent}%;"></div>
        <span class="bar-label">${d.day}</span>
      `;
      chart.appendChild(col);
    });
  }

  function renderTopProducts(products) {
    const list = document.getElementById('top-products-list');
    list.innerHTML = '';

    if (!products || products.length === 0) {
      list.innerHTML = '<p style="font-size:0.85rem; color:var(--text-secondary);">No sales registered yet.</p>';
      return;
    }

    products.forEach(p => {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex; justify-content:space-between; align-items:center; padding: 0.6rem 0; border-bottom: 1px solid var(--border-soft);';
      row.innerHTML = `
        <div>
          <strong style="font-size: 0.9rem;">${p.name}</strong>
          <div style="font-size: 0.75rem; color: var(--text-secondary);">${p.quantity} unit(s) sold</div>
        </div>
        <span style="font-weight: 600; color: var(--gold-dark);">GH₵${p.revenue.toFixed(2)}</span>
      `;
      list.appendChild(row);
    });
  }

  function renderFulfillment(statusObj) {
    const grid = document.getElementById('fulfillment-grid');
    grid.innerHTML = '';

    const statusLabels = {
      pending: 'Pending',
      confirmed: 'Confirmed',
      processing: 'Processing',
      shipped: 'Shipped',
      delivered: 'Delivered',
      cancelled: 'Cancelled'
    };

    Object.entries(statusObj).forEach(([status, count]) => {
      const card = document.createElement('div');
      card.style.cssText = 'background: var(--paper-alt); padding: 1rem; border-radius: var(--radius-sm); text-align: center;';
      card.innerHTML = `
        <div style="font-size: 1.4rem; font-weight: 700; color: var(--ink); margin-bottom: 0.25rem;">${count}</div>
        <div style="font-size: 0.8rem; text-transform: capitalize; color: var(--text-secondary);">${statusLabels[status] || status}</div>
      `;
      grid.appendChild(card);
    });
  }

  loadAnalytics();
});
