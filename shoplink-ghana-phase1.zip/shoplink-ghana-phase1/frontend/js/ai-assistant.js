document.addEventListener('DOMContentLoaded', async () => {
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  const cachedUser = getStoredUser();
  const cachedStore = getStoredStore();
  if (cachedUser) {
    document.getElementById('sidebar-user-name').textContent = cachedUser.name || '—';
    const roleHtml = cachedUser.role === 'admin' 
      ? `<span class="role-badge role-badge-admin">🛡️ Platform Admin</span>` 
      : `<span class="role-badge role-badge-owner">👑 Store Owner</span>`;
    document.getElementById('sidebar-user-role').innerHTML = roleHtml;
    const initials = cachedUser.name
      ? cachedUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
      : '?';
    document.getElementById('sidebar-avatar').textContent = initials;
  }

  if (cachedStore) {
    document.getElementById('chat-store-name').textContent = `${cachedStore.name} AI`;
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

  const form = document.getElementById('ai-settings-form');
  const enabledToggle = document.getElementById('ai-enabled-toggle');
  const personalitySelect = document.getElementById('ai-personality');
  const greetingInput = document.getElementById('ai-greeting');
  const statusPill = document.getElementById('ai-status-pill');

  const chatBody = document.getElementById('chat-body');
  const chatForm = document.getElementById('chat-form');
  const chatInput = document.getElementById('chat-input');

  async function loadSettings() {
    try {
      const res = await apiRequest('/ai/settings');
      const data = res.data;

      enabledToggle.checked = data.aiEnabled;
      personalitySelect.value = data.aiPersonality;
      greetingInput.value = data.aiGreetingMessage;

      updateStatusPill(data.aiEnabled);

      // Initial greeting message in simulator
      appendMessage(data.aiGreetingMessage, 'bot');
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function updateStatusPill(enabled) {
    if (enabled) {
      statusPill.textContent = 'Active';
      statusPill.className = 'status-badge in-stock';
    } else {
      statusPill.textContent = 'Disabled';
      statusPill.className = 'status-badge out-of-stock';
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    setButtonLoading('save-ai-btn', true);

    const payload = {
      aiEnabled: enabledToggle.checked,
      aiPersonality: personalitySelect.value,
      aiGreetingMessage: greetingInput.value.trim()
    };

    try {
      await apiRequest('/ai/settings', {
        method: 'PUT',
        body: payload
      });
      showToast('AI Assistant settings saved!');
      updateStatusPill(payload.aiEnabled);
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setButtonLoading('save-ai-btn', false);
    }
  });

  function appendMessage(text, sender) {
    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${sender}`;
    bubble.textContent = text;
    chatBody.appendChild(bubble);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = chatInput.value.trim();
    if (!text) return;

    appendMessage(text, 'user');
    chatInput.value = '';

    // Show loading typing indicator
    const typingIndicator = document.createElement('div');
    typingIndicator.className = 'chat-bubble bot';
    typingIndicator.textContent = 'Typing...';
    typingIndicator.id = 'typing-indicator';
    chatBody.appendChild(typingIndicator);
    chatBody.scrollTop = chatBody.scrollHeight;

    try {
      const res = await apiRequest('/ai/chat', {
        method: 'POST',
        body: { message: text }
      });
      typingIndicator.remove();
      appendMessage(res.data.reply, 'bot');
    } catch (err) {
      typingIndicator.remove();
      appendMessage('Sorry, I had trouble processing that. Please try again.', 'bot');
    }
  });

  loadSettings();
});
