document.addEventListener('DOMContentLoaded', () => {
  const storeId = new URLSearchParams(window.location.search).get('store');
  const grid = document.getElementById('product-grid');
  const emptyState = document.getElementById('catalogue-empty');
  const message = document.getElementById('catalogue-message');
  const searchInput = document.getElementById('catalogue-search');
  const categorySelect = document.getElementById('catalogue-category');
  const productCount = document.getElementById('product-count');
  const storeName = document.getElementById('store-name');
  const storeDescription = document.getElementById('store-description');
  const storeMeta = document.getElementById('store-meta');

  // Cart DOM elements
  const cartFabBtn = document.getElementById('cart-fab-btn');
  const cartCountBadge = document.getElementById('cart-count-badge');
  const cartDrawerOverlay = document.getElementById('cart-drawer-overlay');
  const cartCloseBtn = document.getElementById('cart-close-btn');
  const cartEmptyMsg = document.getElementById('cart-empty-msg');
  const cartItemsContainer = document.getElementById('cart-items-container');
  const cartSubtotalVal = document.getElementById('cart-subtotal-val');
  const openCheckoutBtn = document.getElementById('open-checkout-btn');

  // Checkout DOM elements
  const checkoutModal = document.getElementById('checkout-modal');
  const checkoutCloseBtn = document.getElementById('checkout-close-btn');
  const checkoutForm = document.getElementById('checkout-form');
  const checkoutError = document.getElementById('checkout-error');
  const checkoutItemsSummary = document.getElementById('checkout-items-summary');
  const checkoutTotalVal = document.getElementById('checkout-total-val');
  const submitOrderBtn = document.getElementById('submit-order-btn');
  const submitWhatsappOrderBtn = document.getElementById('submit-whatsapp-order-btn');

  // Order Success Modal elements
  const orderSuccessModal = document.getElementById('order-success-modal');
  const successOrderNumber = document.getElementById('success-order-number');
  const successWhatsappContainer = document.getElementById('success-whatsapp-container');
  const successDoneBtn = document.getElementById('success-done-btn');

  let catalogue = { store: null, products: [] };
  let searchTerm = '';
  let selectedCategory = 'all';
  let cart = []; // Array of { productId, name, price, quantity, maxQuantity, image }

  // Storage key per store
  const storageKey = storeId ? `shoplink_cart_${storeId}` : null;

  function loadSavedCart() {
    if (!storageKey) return;
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        cart = JSON.parse(saved);
      }
    } catch {
      cart = [];
    }
  }

  function saveCart() {
    if (!storageKey) return;
    try {
      localStorage.setItem(storageKey, JSON.stringify(cart));
    } catch {
      // Ignore storage quota errors
    }
  }

  function updateCartUI() {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCountBadge.textContent = totalItems;

    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    cartSubtotalVal.textContent = formatPrice(subtotal);
    openCheckoutBtn.disabled = cart.length === 0;

    if (cart.length === 0) {
      cartEmptyMsg.style.display = 'block';
      cartItemsContainer.replaceChildren();
    } else {
      cartEmptyMsg.style.display = 'none';
      cartItemsContainer.replaceChildren(...cart.map(createCartItemElement));
    }

    saveCart();
  }

  function addToCart(product, qtyToAdd = 1) {
    const existingIndex = cart.findIndex(item => item.productId === product._id);
    const maxQty = product.quantity || 0;

    if (existingIndex > -1) {
      const currentQty = cart[existingIndex].quantity;
      const newQty = Math.min(maxQty, currentQty + qtyToAdd);
      cart[existingIndex].quantity = newQty;
      cart[existingIndex].maxQuantity = maxQty;
    } else {
      cart.push({
        productId: product._id,
        name: product.name,
        price: product.price,
        quantity: Math.min(maxQty, qtyToAdd),
        maxQuantity: maxQty,
        image: getSafeImageUrl(product.images?.[0]),
      });
    }

    updateCartUI();
    renderProducts();
  }

  function updateCartQuantity(productId, delta) {
    const index = cart.findIndex(item => item.productId === productId);
    if (index === -1) return;

    const newQty = cart[index].quantity + delta;
    if (newQty <= 0) {
      cart.splice(index, 1);
    } else {
      cart[index].quantity = Math.min(cart[index].maxQuantity, newQty);
    }

    updateCartUI();
    renderProducts();
  }

  function removeFromCart(productId) {
    cart = cart.filter(item => item.productId !== productId);
    updateCartUI();
    renderProducts();
  }

  function createCartItemElement(item) {
    const container = document.createElement('div');
    container.className = 'cart-item-row';

    const info = document.createElement('div');
    info.className = 'cart-item-info';
    
    const name = document.createElement('div');
    name.className = 'cart-item-name';
    name.textContent = item.name;
    info.appendChild(name);

    const price = document.createElement('div');
    price.className = 'cart-item-price';
    price.textContent = `${formatPrice(item.price)} each`;
    info.appendChild(price);

    const controls = document.createElement('div');
    controls.className = 'cart-item-controls';

    const minusBtn = document.createElement('button');
    minusBtn.type = 'button';
    minusBtn.className = 'cart-qty-btn';
    minusBtn.textContent = '−';
    minusBtn.addEventListener('click', () => updateCartQuantity(item.productId, -1));

    const qtySpan = document.createElement('span');
    qtySpan.className = 'cart-qty-val';
    qtySpan.textContent = item.quantity;

    const plusBtn = document.createElement('button');
    plusBtn.type = 'button';
    plusBtn.className = 'cart-qty-btn';
    plusBtn.textContent = '+';
    plusBtn.disabled = item.quantity >= item.maxQuantity;
    plusBtn.addEventListener('click', () => updateCartQuantity(item.productId, 1));

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'cart-remove-btn';
    removeBtn.textContent = '🗑️';
    removeBtn.title = 'Remove item';
    removeBtn.addEventListener('click', () => removeFromCart(item.productId));

    controls.appendChild(minusBtn);
    controls.appendChild(qtySpan);
    controls.appendChild(plusBtn);
    controls.appendChild(removeBtn);

    const total = document.createElement('strong');
    total.className = 'cart-item-total';
    total.textContent = formatPrice(item.price * item.quantity);

    container.appendChild(info);
    container.appendChild(controls);
    container.appendChild(total);
    return container;
  }

  function setMessage(text, type = '') {
    message.textContent = text || '';
    message.className = text ? `storefront-message ${type}`.trim() : 'storefront-message';
  }

  function formatPrice(value) {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return '';
    const currency = catalogue.store?.currency || 'GHS';

    try {
      return new Intl.NumberFormat('en-GH', {
        style: 'currency',
        currency,
        minimumFractionDigits: 2,
      }).format(amount);
    } catch {
      return `GH₵${amount.toFixed(2)}`;
    }
  }

  function getSafeImageUrl(value) {
    if (!value) return '';
    try {
      const url = new URL(value, window.location.origin);
      return url.protocol === 'http:' || url.protocol === 'https:' ? url.href : '';
    } catch {
      return '';
    }
  }

  function normalizeWhatsAppPhone(value) {
    const digits = String(value || '').replace(/\D/g, '');
    if (digits.startsWith('00')) return digits.slice(2);
    if (digits.startsWith('0') && digits.length === 10) return `233${digits.slice(1)}`;
    return digits.length >= 8 && digits.length <= 15 ? digits : '';
  }

  function appendMetaItem(label, value) {
    if (!value) return;
    const item = document.createElement('span');
    item.className = 'storefront-meta-item';
    const labelNode = document.createElement('strong');
    labelNode.textContent = `${label}: `;
    item.appendChild(labelNode);
    item.appendChild(document.createTextNode(value));
    storeMeta.appendChild(item);
  }

  function renderStore() {
    const store = catalogue.store || {};
    storeName.textContent = store.name || 'Store catalogue';
    storeDescription.textContent = store.description || 'Browse our available products.';
    storeMeta.replaceChildren();
    appendMetaItem('Location', [store.city, store.country].filter(Boolean).join(', '));
    appendMetaItem('Contact', store.phone || store.email);
  }

  function populateCategories() {
    const categories = [...new Set(
      catalogue.products
        .map(product => product.category || 'General')
        .filter(Boolean)
        .sort((a, b) => a.localeCompare(b))
    )];
    const previousValue = selectedCategory;
    categorySelect.replaceChildren(
      Object.assign(document.createElement('option'), {
        value: 'all',
        textContent: 'All categories',
      })
    );
    categories.forEach(category => {
      const option = document.createElement('option');
      option.value = category;
      option.textContent = category;
      categorySelect.appendChild(option);
    });
    selectedCategory = categories.includes(previousValue) ? previousValue : 'all';
    categorySelect.value = selectedCategory;
  }

  function getVisibleProducts() {
    const query = searchTerm.trim().toLowerCase();
    return catalogue.products.filter(product => {
      const matchesSearch = !query || [
        product.name,
        product.description,
        product.category,
        product.sku,
      ].filter(Boolean).some(value => value.toLowerCase().includes(query));
      const matchesCategory = selectedCategory === 'all' ||
        (product.category || 'General') === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }

  function createProductCard(product) {
    const card = document.createElement('article');
    card.className = 'product-card';

    const media = document.createElement('div');
    media.className = 'product-card-media';
    const imageUrl = getSafeImageUrl(product.images?.[0]);
    if (imageUrl) {
      const image = document.createElement('img');
      image.src = imageUrl;
      image.alt = product.name || 'Product image';
      image.loading = 'lazy';
      media.appendChild(image);
    } else {
      const placeholder = document.createElement('div');
      placeholder.className = 'product-card-placeholder';
      placeholder.textContent = (product.name || 'Product').slice(0, 1).toUpperCase();
      media.appendChild(placeholder);
    }
    card.appendChild(media);

    const body = document.createElement('div');
    body.className = 'product-card-body';

    const category = document.createElement('span');
    category.className = 'product-card-category';
    category.textContent = product.category || 'General';
    body.appendChild(category);

    const title = document.createElement('h2');
    title.className = 'product-card-title';
    title.textContent = product.name || 'Untitled product';
    body.appendChild(title);

    const description = document.createElement('p');
    description.className = 'product-card-description';
    description.textContent = product.description || 'No description available.';
    body.appendChild(description);

    const details = document.createElement('div');
    details.className = 'product-card-details';
    const price = document.createElement('strong');
    price.className = 'product-card-price';
    price.textContent = formatPrice(product.price);
    details.appendChild(price);

    const stock = document.createElement('span');
    const inStock = product.inStock !== false && product.quantity > 0;
    stock.className = `product-card-stock ${inStock ? '' : 'out-of-stock'}`;
    stock.textContent = inStock ? `${product.quantity} in stock` : 'Out of Stock';
    details.appendChild(stock);
    body.appendChild(details);

    // Cart action buttons
    const actionsRow = document.createElement('div');
    actionsRow.className = 'product-card-actions';

    if (inStock) {
      const cartItem = cart.find(item => item.productId === product._id);
      
      const addBtn = document.createElement('button');
      addBtn.type = 'button';
      addBtn.className = 'btn btn-primary product-add-cart-btn';
      if (cartItem) {
        addBtn.textContent = `In Cart (${cartItem.quantity}) +`;
      } else {
        addBtn.textContent = '🛒 Add to Cart';
      }
      addBtn.addEventListener('click', () => {
        addToCart(product, 1);
      });
      actionsRow.appendChild(addBtn);

      const buyNowBtn = document.createElement('button');
      buyNowBtn.type = 'button';
      buyNowBtn.className = 'btn btn-outline product-buy-now-btn';
      buyNowBtn.textContent = '⚡ Buy Now';
      buyNowBtn.addEventListener('click', () => {
        addToCart(product, 1);
        openCartDrawer();
      });
      actionsRow.appendChild(buyNowBtn);
    } else {
      const disabledBtn = document.createElement('button');
      disabledBtn.type = 'button';
      disabledBtn.className = 'btn btn-outline';
      disabledBtn.disabled = true;
      disabledBtn.textContent = 'Out of Stock';
      actionsRow.appendChild(disabledBtn);
    }

    body.appendChild(actionsRow);
    card.appendChild(body);
    return card;
  }

  function renderProducts() {
    const visibleProducts = getVisibleProducts();
    grid.replaceChildren(...visibleProducts.map(createProductCard));
    emptyState.hidden = visibleProducts.length > 0;
    productCount.textContent = visibleProducts.length === 1
      ? '1 product available'
      : `${visibleProducts.length} products available`;
  }

  // Drawer handlers
  function openCartDrawer() {
    cartDrawerOverlay.hidden = false;
  }

  function closeCartDrawer() {
    cartDrawerOverlay.hidden = true;
  }

  cartFabBtn.addEventListener('click', openCartDrawer);
  cartCloseBtn.addEventListener('click', closeCartDrawer);
  cartDrawerOverlay.addEventListener('click', event => {
    if (event.target === cartDrawerOverlay) closeCartDrawer();
  });

  // Checkout modal handlers
  function openCheckoutModal() {
    if (cart.length === 0) return;
    closeCartDrawer();
    clearError('checkout-error');
    
    // Populate summary in modal
    checkoutItemsSummary.replaceChildren(...cart.map(item => {
      const div = document.createElement('div');
      div.className = 'checkout-item-line';
      div.innerHTML = `<span>${item.name} × ${item.quantity}</span><strong>${formatPrice(item.price * item.quantity)}</strong>`;
      return div;
    }));

    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    checkoutTotalVal.textContent = formatPrice(subtotal);
    checkoutModal.classList.add('active');
  }

  function closeCheckoutModal() {
    checkoutModal.classList.remove('active');
  }

  openCheckoutBtn.addEventListener('click', openCheckoutModal);
  checkoutCloseBtn.addEventListener('click', closeCheckoutModal);

  // Submit Order logic (Web Direct or WhatsApp)
  async function submitOrderProcess(isWhatsAppFlow = false) {
    if (cart.length === 0) return;

    clearError('checkout-error');
    setButtonLoading('submit-order-btn', true);
    submitWhatsappOrderBtn.disabled = true;

    const customerName = document.getElementById('cust-name').value.trim();
    const customerPhone = document.getElementById('cust-phone').value.trim();
    const customerEmail = document.getElementById('cust-email').value.trim();
    const notes = document.getElementById('cust-notes').value.trim();

    if (!customerName || !customerPhone) {
      showError('checkout-error', 'Please provide both your name and phone number.');
      setButtonLoading('submit-order-btn', false);
      submitWhatsappOrderBtn.disabled = false;
      return;
    }

    const payload = {
      customerName,
      customerPhone,
      customerEmail,
      notes,
      items: cart.map(i => ({ productId: i.productId, quantity: i.quantity })),
    };

    try {
      const response = await apiRequest(`/storefront/${encodeURIComponent(storeId)}/orders`, {
        method: 'POST',
        body: payload,
      });

      const orderData = response.data;
      const orderNum = orderData.orderNumber || 'ORD-0001';

      // Clear local cart
      cart = [];
      updateCartUI();
      closeCheckoutModal();

      // Show success modal
      successOrderNumber.textContent = orderNum;
      successWhatsappContainer.replaceChildren();

      const phone = normalizeWhatsAppPhone(catalogue.store?.phone);
      if (phone) {
        const messageText = `Hello *${catalogue.store?.name || 'Store'}*,\nI have placed order *${orderNum}* on your shop!\n\n` +
          `*Order Details:*\n` +
          orderData.items.map(i => `• ${i.name} (x${i.quantity}) - ${formatPrice(i.price * i.quantity)}`).join('\n') +
          `\n\n*Total Amount:* ${formatPrice(orderData.total)}\n` +
          `*Customer Name:* ${customerName}\n` +
          `*Phone:* ${customerPhone}\n` +
          (notes ? `*Delivery Notes:* ${notes}\n` : '');

        const waUrl = `https://wa.me/${phone}?text=${encodeURIComponent(messageText)}`;

        const waBtn = document.createElement('a');
        waBtn.className = 'btn btn-primary';
        waBtn.style.cssText = 'background: #25D366; color: #fff; text-decoration: none;';
        waBtn.href = waUrl;
        waBtn.target = '_blank';
        waBtn.rel = 'noopener noreferrer';
        waBtn.textContent = 'Confirm Order on WhatsApp 💬';
        successWhatsappContainer.appendChild(waBtn);

        if (isWhatsAppFlow) {
          window.open(waUrl, '_blank');
        }
      }

      orderSuccessModal.classList.add('active');

      // Reload catalogue to reflect reduced stock
      await loadCatalogue();
    } catch (err) {
      showError('checkout-error', err.message || 'Failed to place order. Please try again.');
    } finally {
      setButtonLoading('submit-order-btn', false);
      submitWhatsappOrderBtn.disabled = false;
    }
  }

  checkoutForm.addEventListener('submit', event => {
    event.preventDefault();
    submitOrderProcess(false);
  });

  submitWhatsappOrderBtn.addEventListener('click', () => {
    submitOrderProcess(true);
  });

  successDoneBtn.addEventListener('click', () => {
    orderSuccessModal.classList.remove('active');
  });

  searchInput.addEventListener('input', event => {
    searchTerm = event.target.value;
    renderProducts();
  });

  categorySelect.addEventListener('change', event => {
    selectedCategory = event.target.value;
    renderProducts();
  });

  async function loadCatalogue() {
    if (!storeId) {
      setMessage('This catalogue link is missing a store identifier.', 'error');
      productCount.textContent = 'Catalogue unavailable';
      return;
    }

    setMessage('Loading catalogue…');
    try {
      const response = await apiRequest(`/storefront/${encodeURIComponent(storeId)}/products`);
      catalogue = response.data || { store: null, products: [] };
      renderStore();
      populateCategories();
      loadSavedCart();
      updateCartUI();
      renderProducts();
      setMessage('');
    } catch (error) {
      setMessage(error.message || 'Unable to load this catalogue.', 'error');
      productCount.textContent = 'Catalogue unavailable';
      grid.replaceChildren();
      emptyState.hidden = true;
    }
  }

  loadCatalogue();
});

