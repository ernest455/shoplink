document.addEventListener('DOMContentLoaded', async () => {
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  const cachedUser = getStoredUser();
  if (cachedUser) {
    document.getElementById('sidebar-user-name').textContent = cachedUser.name || '—';
    const roleHtml = cachedUser.role === 'admin' 
      ? `<span class="role-badge role-badge-admin">🛡️ Platform Admin</span>` 
      : `<span class="role-badge role-badge-owner">👑 Store Owner</span>`;
    document.getElementById('sidebar-user-role').innerHTML = roleHtml;
    const initials = cachedUser.name
      ? cachedUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
      : '?';
    document.getElementById('sidebar-avatar').textContent = initials;
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

  const tbody = document.getElementById('customers-tbody');
  const emptyState = document.getElementById('empty-state');
  const modal = document.getElementById('customer-modal');
  const addBtn = document.getElementById('add-customer-btn');
  const closeBtn = document.getElementById('customer-modal-close-btn');
  const cancelBtn = document.getElementById('customer-cancel-btn');
  const form = document.getElementById('customer-form');

  let customers = [];

  async function loadCustomers() {
    try {
      const res = await apiRequest('/customers');
      customers = res.data;
      renderCustomers();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function renderCustomers() {
    tbody.innerHTML = '';
    if (!customers || customers.length === 0) {
      emptyState.style.display = 'block';
      return;
    }
    emptyState.style.display = 'none';

    customers.forEach(c => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${c.name}</strong></td>
        <td>${c.phone}</td>
        <td>${c.email || '—'}</td>
        <td>${c.totalOrders || 0}</td>
        <td>GH₵${(c.totalSpent || 0).toFixed(2)}</td>
        <td>
          <button class="btn btn-ghost delete-btn" data-id="${c._id}" style="padding: 0.35rem 0.65rem; font-size: 0.8rem; color: var(--error);">Delete</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', () => deleteCustomerItem(btn.getAttribute('data-id')));
    });
  }

  function openModal() {
    form.reset();
    clearError('customer-form-error');
    modal.classList.add('active');
  }

  function closeModal() {
    modal.classList.remove('active');
  }

  addBtn.addEventListener('click', openModal);
  closeBtn.addEventListener('click', closeModal);
  cancelBtn.addEventListener('click', closeModal);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearError('customer-form-error');
    setButtonLoading('save-customer-btn', true);

    const payload = {
      name: document.getElementById('customer-name').value.trim(),
      phone: document.getElementById('customer-phone').value.trim(),
      email: document.getElementById('customer-email').value.trim(),
      notes: document.getElementById('customer-notes').value.trim()
    };

    try {
      await apiRequest('/customers', { method: 'POST', body: payload });
      showToast('Customer added successfully!');
      closeModal();
      loadCustomers();
    } catch (err) {
      showError('customer-form-error', err.message);
    } finally {
      setButtonLoading('save-customer-btn', false);
    }
  });

  async function deleteCustomerItem(id) {
    if (!confirm('Are you sure you want to delete this customer?')) return;
    try {
      await apiRequest(`/customers/${id}`, { method: 'DELETE' });
      showToast('Customer deleted');
      loadCustomers();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  loadCustomers();
});
