document.addEventListener('DOMContentLoaded', async () => {
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  const cachedUser = getStoredUser();
  if (cachedUser) {
    document.getElementById('sidebar-user-name').textContent = cachedUser.name || '—';
    const roleHtml = cachedUser.role === 'admin' 
      ? `<span class="role-badge role-badge-admin">🛡️ Platform Admin</span>` 
      : `<span class="role-badge role-badge-owner">👑 Store Owner</span>`;
    document.getElementById('sidebar-user-role').innerHTML = roleHtml;
    const initials = cachedUser.name
      ? cachedUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
      : '?';
    document.getElementById('sidebar-avatar').textContent = initials;
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

  const form = document.getElementById('whatsapp-form');
  const statusPill = document.getElementById('connection-status-pill');
  const webhookInput = document.getElementById('webhook-url');
  const verifyTokenInput = document.getElementById('verify-token');

  async function loadConfig() {
    try {
      const res = await apiRequest('/whatsapp/config');
      const data = res.data;

      document.getElementById('phone-number-id').value = data.whatsappPhoneNumberId || '';
      document.getElementById('waba-id').value = data.whatsappBusinessAccountId || '';
      webhookInput.value = data.webhookUrl;
      verifyTokenInput.value = data.verifyToken;

      if (data.isConnected) {
        statusPill.textContent = 'Connected';
        statusPill.className = 'status-badge in-stock';
      } else {
        statusPill.textContent = 'Not Connected';
        statusPill.className = 'status-badge out-of-stock';
      }
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    setButtonLoading('save-whatsapp-btn', true);

    const payload = {
      whatsappPhoneNumberId: document.getElementById('phone-number-id').value.trim(),
      whatsappBusinessAccountId: document.getElementById('waba-id').value.trim(),
      whatsappAccessToken: document.getElementById('access-token').value.trim()
    };

    try {
      const res = await apiRequest('/whatsapp/config', {
        method: 'PUT',
        body: payload
      });
      showToast('WhatsApp configuration saved!');
      loadConfig();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setButtonLoading('save-whatsapp-btn', false);
    }
  });

  loadConfig();
});
