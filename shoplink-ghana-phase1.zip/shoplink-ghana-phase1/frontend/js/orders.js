document.addEventListener('DOMContentLoaded', async () => {
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  const cachedUser = getStoredUser();
  if (cachedUser) {
    document.getElementById('sidebar-user-name').textContent = cachedUser.name || '—';
    const roleHtml = cachedUser.role === 'admin' 
      ? `<span class="role-badge role-badge-admin">🛡️ Platform Admin</span>` 
      : `<span class="role-badge role-badge-owner">👑 Store Owner</span>`;
    document.getElementById('sidebar-user-role').innerHTML = roleHtml;
    const initials = cachedUser.name
      ? cachedUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
      : '?';
    document.getElementById('sidebar-avatar').textContent = initials;
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

  const tbody = document.getElementById('orders-tbody');
  const emptyState = document.getElementById('empty-state');
  const modal = document.getElementById('status-modal');
  const closeBtn = document.getElementById('status-modal-close-btn');
  const cancelBtn = document.getElementById('status-cancel-btn');
  const form = document.getElementById('status-form');

  let orders = [];

  async function loadOrders() {
    try {
      const res = await apiRequest('/orders');
      orders = res.data;
      renderOrders();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function renderOrders() {
    tbody.innerHTML = '';
    if (!orders || orders.length === 0) {
      emptyState.style.display = 'block';
      return;
    }
    emptyState.style.display = 'none';

    orders.forEach(o => {
      const tr = document.createElement('tr');
      const dateStr = new Date(o.createdAt).toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });

      tr.innerHTML = `
        <td><strong>${o.orderNumber || '—'}</strong></td>
        <td>${o.customerName || 'Walk-in Customer'}</td>
        <td>${o.customerPhone || '—'}</td>
        <td>GH₵${o.total.toFixed(2)}</td>
        <td>
          <span class="status-badge ${o.status}">
            ${o.status}
          </span>
        </td>
        <td>${dateStr}</td>
        <td>
          <button class="btn btn-outline update-btn" data-id="${o._id}" data-status="${o.status}" style="padding: 0.35rem 0.65rem; font-size: 0.8rem;">Update Status</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    document.querySelectorAll('.update-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        const currentStatus = btn.getAttribute('data-status');
        openStatusModal(id, currentStatus);
      });
    });
  }

  function openStatusModal(id, currentStatus) {
    document.getElementById('order-id').value = id;
    document.getElementById('order-status-select').value = currentStatus;
    modal.classList.add('active');
  }

  function closeModal() {
    modal.classList.remove('active');
  }

  closeBtn.addEventListener('click', closeModal);
  cancelBtn.addEventListener('click', closeModal);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    setButtonLoading('save-status-btn', true);

    const id = document.getElementById('order-id').value;
    const status = document.getElementById('order-status-select').value;

    try {
      await apiRequest(`/orders/${id}/status`, {
        method: 'PUT',
        body: { status }
      });
      showToast('Order status updated!');
      closeModal();
      loadOrders();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setButtonLoading('save-status-btn', false);
    }
  });

  loadOrders();
});
