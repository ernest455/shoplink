document.addEventListener('DOMContentLoaded', async () => {
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  const cachedUser = getStoredUser();
  if (cachedUser) {
    document.getElementById('sidebar-user-name').textContent = cachedUser.name || '—';
    const roleHtml = cachedUser.role === 'admin'
      ? '<span class="role-badge role-badge-admin">Platform Admin</span>'
      : '<span class="role-badge role-badge-owner">Store Owner</span>';
    document.getElementById('sidebar-user-role').innerHTML = roleHtml;
    const initials = cachedUser.name
      ? cachedUser.name.trim().split(/\s+/).map(name => name[0]).join('').slice(0, 2).toUpperCase()
      : '?';
    document.getElementById('sidebar-avatar').textContent = initials;
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

  const tbody = document.getElementById('products-tbody');
  const emptyState = document.getElementById('empty-state');
  const modal = document.getElementById('product-modal');
  const addBtn = document.getElementById('add-product-btn');
  const closeBtn = document.getElementById('modal-close-btn');
  const cancelBtn = document.getElementById('modal-cancel-btn');
  const form = document.getElementById('product-form');
  const catalogueLink = document.getElementById('view-catalogue-btn');

  let products = [];

  async function loadProducts() {
    try {
      const response = await apiRequest('/products');
      products = response.data || [];
      renderProducts();
    } catch (error) {
      if (error.message.includes('token')) {
        clearSession();
        window.location.replace('login.html');
        return;
      }
      showToast(error.message, 'error');
    }
  }

  async function loadCatalogueLink() {
    try {
      const response = await apiRequest('/store');
      const store = response.data;
      const storeId = store?._id || store?.id;
      if (storeId && catalogueLink) {
        catalogueLink.href = `storefront.html?store=${encodeURIComponent(storeId)}`;
      } else if (catalogueLink) {
        catalogueLink.hidden = true;
      }
    } catch (error) {
      if (catalogueLink) catalogueLink.hidden = true;
      showToast(error.message, 'error');
    }
  }

  function formatPrice(value) {
    const amount = Number(value);
    return Number.isFinite(amount) ? `GH₵${amount.toFixed(2)}` : '—';
  }

  function appendCell(row, value, options = {}) {
    const cell = document.createElement('td');
    const content = document.createTextNode(value == null || value === '' ? (options.fallback || '—') : String(value));
    cell.appendChild(content);
    if (options.className) cell.className = options.className;
    row.appendChild(cell);
    return cell;
  }

  function renderProducts() {
    tbody.replaceChildren();
    emptyState.style.display = products.length ? 'none' : 'block';

    products.forEach(product => {
      const row = document.createElement('tr');
      const nameCell = document.createElement('td');
      const name = document.createElement('strong');
      name.textContent = product.name || 'Untitled product';
      nameCell.appendChild(name);
      row.appendChild(nameCell);
      appendCell(row, product.category || 'General');
      appendCell(row, formatPrice(product.price));
      appendCell(row, Number(product.quantity) || 0);

      const inStock = product.inStock !== false && Number(product.quantity) > 0;
      const statusCell = document.createElement('td');
      const status = document.createElement('span');
      status.className = `status-badge ${inStock ? 'in-stock' : 'out-of-stock'}`;
      status.textContent = inStock ? 'In Stock' : 'Out of Stock';
      statusCell.appendChild(status);
      row.appendChild(statusCell);

      const actionsCell = document.createElement('td');
      const editBtn = document.createElement('button');
      editBtn.type = 'button';
      editBtn.className = 'btn btn-outline edit-btn';
      editBtn.style.cssText = 'padding: 0.35rem 0.65rem; font-size: 0.8rem; margin-right: 0.25rem;';
      editBtn.textContent = 'Edit';
      editBtn.dataset.id = product._id;
      editBtn.addEventListener('click', () => openEditModal(product._id));
      actionsCell.appendChild(editBtn);

      const deleteBtn = document.createElement('button');
      deleteBtn.type = 'button';
      deleteBtn.className = 'btn btn-ghost delete-btn';
      deleteBtn.style.cssText = 'padding: 0.35rem 0.65rem; font-size: 0.8rem; color: var(--error);';
      deleteBtn.textContent = 'Delete';
      deleteBtn.dataset.id = product._id;
      deleteBtn.addEventListener('click', () => deleteProductItem(product._id));
      actionsCell.appendChild(deleteBtn);
      row.appendChild(actionsCell);
      tbody.appendChild(row);
    });
  }

  function resetForm() {
    form.reset();
    document.getElementById('product-published').checked = true;
    clearError('product-form-error');
  }

  function openAddModal() {
    document.getElementById('modal-title').textContent = 'Add New Product';
    document.getElementById('product-id').value = '';
    resetForm();
    modal.classList.add('active');
    document.getElementById('product-name').focus();
  }

  function openEditModal(id) {
    const product = products.find(item => item._id === id);
    if (!product) return;

    document.getElementById('modal-title').textContent = 'Edit Product';
    document.getElementById('product-id').value = product._id;
    document.getElementById('product-name').value = product.name || '';
    document.getElementById('product-price').value = product.price ?? '';
    document.getElementById('product-quantity').value = product.quantity ?? 0;
    document.getElementById('product-category').value = product.category || '';
    document.getElementById('product-image').value = product.images?.[0] || '';
    document.getElementById('product-description').value = product.description || '';
    document.getElementById('product-published').checked = product.published !== false;
    clearError('product-form-error');
    modal.classList.add('active');
  }

  function closeModal() {
    modal.classList.remove('active');
  }

  const emptyAddBtn = document.getElementById('empty-add-btn');
  const seedSampleBtn = document.getElementById('seed-sample-btn');

  if (emptyAddBtn) emptyAddBtn.addEventListener('click', openAddModal);

  if (seedSampleBtn) {
    seedSampleBtn.addEventListener('click', async () => {
      seedSampleBtn.disabled = true;
      seedSampleBtn.textContent = 'Adding samples…';

      const sampleProducts = [
        {
          name: 'Kente Cloth Print Dress',
          price: 350,
          quantity: 15,
          category: 'Fashion',
          description: 'Authentic Ghanaian handcrafted Kente print dress, suitable for special occasions.',
          images: ['https://images.unsplash.com/photo-1590736704728-f4730bb30770?w=600&auto=format&fit=crop'],
          published: true,
        },
        {
          name: 'Handcrafted Leather Sandals',
          price: 180,
          quantity: 25,
          category: 'Footwear',
          description: 'Durable and comfortable genuine leather sandals made locally in Kumasi.',
          images: ['https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&auto=format&fit=crop'],
          published: true,
        },
        {
          name: 'Organic Shea Butter Soap (3 Pack)',
          price: 60,
          quantity: 50,
          category: 'Beauty',
          description: '100% pure raw unrefined shea butter soap for nourishing skin and hair.',
          images: ['https://images.unsplash.com/photo-1607006482686-2ed5ff199026?w=600&auto=format&fit=crop'],
          published: true,
        },
        {
          name: 'Ghana Cocoa Gold Powder (500g)',
          price: 45,
          quantity: 40,
          category: 'Food',
          description: 'Premium rich Ghanaian natural cocoa powder. Great for hot chocolate and baking.',
          images: ['https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=600&auto=format&fit=crop'],
          published: true,
        },
      ];

      try {
        for (const item of sampleProducts) {
          await apiRequest('/products', { method: 'POST', body: item });
        }
        showToast('Sample products added successfully! 🎉');
        await loadProducts();
      } catch (err) {
        showToast(err.message || 'Failed to add sample products', 'error');
      } finally {
        seedSampleBtn.disabled = false;
        seedSampleBtn.textContent = '✨ Add Sample Products';
      }
    });
  }

  addBtn.addEventListener('click', openAddModal);
  closeBtn.addEventListener('click', closeModal);
  cancelBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', event => {
    if (event.target === modal) closeModal();
  });


  form.addEventListener('submit', async event => {
    event.preventDefault();
    clearError('product-form-error');
    setButtonLoading('save-product-btn', true);

    const id = document.getElementById('product-id').value;
    const imageUrl = document.getElementById('product-image').value.trim();
    const payload = {
      name: document.getElementById('product-name').value.trim(),
      price: Number(document.getElementById('product-price').value),
      quantity: Number(document.getElementById('product-quantity').value),
      category: document.getElementById('product-category').value.trim(),
      description: document.getElementById('product-description').value.trim(),
      images: imageUrl ? [imageUrl] : [],
      published: document.getElementById('product-published').checked,
    };

    try {
      if (id) {
        await apiRequest(`/products/${encodeURIComponent(id)}`, { method: 'PUT', body: payload });
        showToast('Product updated successfully!');
      } else {
        await apiRequest('/products', { method: 'POST', body: payload });
        showToast('Product added successfully!');
      }
      closeModal();
      await loadProducts();
    } catch (error) {
      showError('product-form-error', error.message);
    } finally {
      setButtonLoading('save-product-btn', false);
    }
  });

  async function deleteProductItem(id) {
    if (!window.confirm('Are you sure you want to delete this product?')) return;
    try {
      await apiRequest(`/products/${encodeURIComponent(id)}`, { method: 'DELETE' });
      showToast('Product deleted');
      await loadProducts();
    } catch (error) {
      showToast(error.message, 'error');
    }
  }

  await Promise.all([loadProducts(), loadCatalogueLink()]);
});
