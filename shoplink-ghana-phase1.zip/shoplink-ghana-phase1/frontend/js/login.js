// ── login.js ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Already logged in → skip to dashboard
  if (getToken()) {
    window.location.replace('dashboard.html');
    return;
  }

  const form     = document.getElementById('login-form');
  const errorBox = 'form-error';
  const submitId = 'submit-btn';

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearError(errorBox);

    const email    = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;

    if (!email || !password) {
      showError(errorBox, 'Please enter your email and password.');
      return;
    }

    setButtonLoading(submitId, true);

    try {
      const { data } = await apiRequest('/auth/login', {
        method: 'POST',
        body: { email, password },
      });

      saveSession(data);
      window.location.replace('dashboard.html');
    } catch (err) {
      showError(errorBox, err.message || 'Login failed. Please try again.');
      setButtonLoading(submitId, false);
    }
  });
});
