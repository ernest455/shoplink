// ── config.js ──────────────────────────────────────────────
// Single source of truth for the backend API URL.
// The backend Express server serves the frontend statically, so
// a relative /api path works with zero configuration locally.
// In production (separate deploy), swap this for the full URL.
const API_BASE_URL = '/api';
