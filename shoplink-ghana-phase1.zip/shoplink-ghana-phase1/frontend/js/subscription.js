document.addEventListener('DOMContentLoaded', async () => {
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  const cachedUser = getStoredUser();
  if (cachedUser) {
    document.getElementById('sidebar-user-name').textContent = cachedUser.name || '—';
    const roleHtml = cachedUser.role === 'admin' 
      ? `<span class="role-badge role-badge-admin">🛡️ Platform Admin</span>` 
      : `<span class="role-badge role-badge-owner">👑 Store Owner</span>`;
    document.getElementById('sidebar-user-role').innerHTML = roleHtml;
    const initials = cachedUser.name
      ? cachedUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
      : '?';
    document.getElementById('sidebar-avatar').textContent = initials;
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

  const container = document.getElementById('pricing-container');
  const planBadge = document.getElementById('current-plan-badge');

  let currentPlan = 'starter';

  async function loadSubscription() {
    try {
      const res = await apiRequest('/store/subscription');
      const { plan, status, plans } = res.data;
      currentPlan = plan;

      planBadge.textContent = `${plan.toUpperCase()} Plan (${status})`;
      renderPlans(plans);
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function renderPlans(plans) {
    container.innerHTML = '';

    plans.forEach(p => {
      const isCurrent = p.id === currentPlan;
      const card = document.createElement('div');
      card.className = `pricing-card ${p.popular ? 'popular' : ''}`;

      card.innerHTML = `
        ${p.popular ? '<span class="popular-tag">Most Popular</span>' : ''}
        <h3 style="font-size: 1.25rem;">${p.name}</h3>
        <div class="price-num">GH₵${p.price}<span style="font-size: 0.85rem; font-family: var(--font-body); font-weight: normal; color: var(--text-secondary);">/mo</span></div>
        <ul class="feature-list">
          ${p.features.map(f => `<li>${f}</li>`).join('')}
        </ul>
        <button class="btn ${isCurrent ? 'btn-outline' : 'btn-primary'} upgrade-btn" data-plan="${p.id}" ${isCurrent ? 'disabled' : ''}>
          ${isCurrent ? 'Current Plan' : 'Upgrade Plan'}
        </button>
      `;

      container.appendChild(card);
    });

    document.querySelectorAll('.upgrade-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const planId = btn.getAttribute('data-plan');
        if (planId !== currentPlan) {
          handleUpgrade(planId);
        }
      });
    });
  }

  async function handleUpgrade(planId) {
    if (!confirm(`Upgrade your subscription to the ${planId.toUpperCase()} plan?`)) return;

    try {
      const res = await apiRequest('/store/subscription/upgrade', {
        method: 'POST',
        body: { plan: planId }
      });
      showToast(res.message);
      loadSubscription();

      // Update cached store plan
      const s = getStoredStore() || {};
      s.subscriptionPlan = planId;
      saveSession({ token: getToken(), user: getStoredUser(), store: s });
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  loadSubscription();
});
