document.addEventListener('DOMContentLoaded', async () => {
  if (!getToken()) {
    window.location.replace('login.html');
    return;
  }

  const cachedUser = getStoredUser();
  if (cachedUser) {
    document.getElementById('sidebar-user-name').textContent = cachedUser.name || '—';
    const roleHtml = cachedUser.role === 'admin' 
      ? `<span class="role-badge role-badge-admin">🛡️ Platform Admin</span>` 
      : `<span class="role-badge role-badge-owner">👑 Store Owner</span>`;
    document.getElementById('sidebar-user-role').innerHTML = roleHtml;
    const initials = cachedUser.name
      ? cachedUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
      : '?';
    document.getElementById('sidebar-avatar').textContent = initials;
  }

  document.getElementById('logout-btn').addEventListener('click', () => {
    clearSession();
    window.location.replace('login.html');
  });

  const tbody = document.getElementById('sales-tbody');
  const emptyState = document.getElementById('empty-sales');

  async function loadSales() {
    try {
      const [analyticsRes, ordersRes] = await Promise.all([
        apiRequest('/analytics'),
        apiRequest('/orders')
      ]);

      const metrics = analyticsRes.data.metrics;
      const orders = ordersRes.data || [];

      document.getElementById('sales-gross').textContent = `GH₵${metrics.totalRevenue.toFixed(2)}`;
      document.getElementById('sales-aov').textContent = `GH₵${metrics.averageOrderValue.toFixed(2)}`;

      // Calculate total units sold
      let totalUnits = 0;
      orders.forEach(o => {
        (o.items || []).forEach(i => {
          totalUnits += (i.quantity || 1);
        });
      });
      document.getElementById('sales-units').textContent = totalUnits;

      renderSalesTable(orders);
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  function renderSalesTable(orders) {
    tbody.innerHTML = '';
    if (!orders || orders.length === 0) {
      emptyState.style.display = 'block';
      return;
    }
    emptyState.style.display = 'none';

    orders.forEach(o => {
      const tr = document.createElement('tr');
      const dateStr = new Date(o.createdAt).toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });

      tr.innerHTML = `
        <td><strong>${o.orderNumber || '—'}</strong></td>
        <td>${o.customerName || 'Walk-in'}</td>
        <td><span class="status-badge" style="background: rgba(217, 164, 65, 0.15); color: var(--gold-dark);">Mobile Money / Cash</span></td>
        <td>GH₵${o.total.toFixed(2)}</td>
        <td><span class="status-badge ${o.status}">${o.status}</span></td>
        <td>${dateStr}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  loadSales();
});
