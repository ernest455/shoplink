// ── register.js ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Already logged in → skip to dashboard
  if (getToken()) {
    window.location.replace('dashboard.html');
    return;
  }

  const form     = document.getElementById('register-form');
  const errorBox = 'form-error';
  const submitId = 'submit-btn';

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearError(errorBox);

    const name            = document.getElementById('name').value.trim();
    const storeName       = document.getElementById('store-name').value.trim();
    const email           = document.getElementById('email').value.trim();
    const password        = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    // Client-side validation
    if (!name || !storeName || !email || !password || !confirmPassword) {
      showError(errorBox, 'Please fill in all fields.');
      return;
    }

    if (password.length < 6) {
      showError(errorBox, 'Password must be at least 6 characters.');
      return;
    }

    if (password !== confirmPassword) {
      showError(errorBox, 'Passwords do not match.');
      return;
    }

    setButtonLoading(submitId, true);

    try {
      const { data } = await apiRequest('/auth/register', {
        method: 'POST',
        body: { name, email, password, storeName },
      });

      saveSession(data);
      window.location.replace('dashboard.html');
    } catch (err) {
      showError(errorBox, err.message || 'Registration failed. Please try again.');
      setButtonLoading(submitId, false);
    }
  });
});
