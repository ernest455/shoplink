# Database design

MongoDB via Mongoose. Every collection that belongs to a business (all of
them except `User`) is scoped by `storeId` — this is what keeps one
business's data invisible to every other business (multi-tenancy).

## User

One document per person who can log into the ShopLink dashboard.

One document per item in a store's catalogue. Products are scoped by
`storeId`, so a store can only manage its own catalogue.

| Field | Type | Notes |
|---|---|---|
| `storeId` | ObjectId → `Store` | required; owner store |
| `name` | String | required, max 120 characters |
| `description` | String | optional, max 1000 characters |
| `price` | Number | required, non-negative |
| `category` | String | defaults to `"General"` |
| `images` | String array | product image URLs |
| `published` | Boolean | defaults to `true`; controls public catalogue visibility |
| `inStock` | Boolean | defaults to `true` |
| `quantity` | Number | non-negative inventory count |
| `sku` | String | optional merchant SKU |
| `createdAt` / `updatedAt` | Date | automatic (`timestamps: true`) |

The public catalogue only returns products that are published, marked in
stock, and have a quantity greater than zero.

One document per person who can log into the ShopLink dashboard.

| Field | Type | Notes |
|---|---|---|
| `name` | String | required |
| `email` | String | required, unique, lowercased |
| `password` | String | bcrypt hash, `select: false` (never returned by default) |
| `role` | String | `owner` \| `admin` |
| `storeId` | ObjectId → `Store` | the business this user manages |
| `createdAt` / `updatedAt` | Date | automatic (`timestamps: true`) |

Customers are **not** `User` documents — they never create a ShopLink
account. They're identified purely by WhatsApp phone number (see the
`Customer` model, added in Phase 3).

## Store

One document per business on the platform. Created automatically the
moment a user registers.

| Field | Type | Notes |
|---|---|---|
| `name` | String | required |
| `description`, `logo`, `phone`, `email`, `address`, `city` | String | optional profile fields |
| `country` | String | default `"Ghana"` |
| `currency` | String | default `"GHS"` |
| `whatsappBusinessAccountId`, `whatsappPhoneNumberId` | String | set in Phase 3 |
| `whatsappAccessToken`, `whatsappVerifyToken` | String | **`select: false`** — set in Phase 3, never sent to the frontend |
| `paystackPublicKey` | String | set in Phase 5. The Paystack **secret** key is never stored in the database — it lives only in the backend's `.env`. |
| `subscriptionPlan` | String | `free` \| `starter` \| `business` \| `pro` |
| `subscriptionStatus` | String | `trial` \| `active` \| `past_due` \| `cancelled` |
| `createdAt` / `updatedAt` | Date | automatic |

`Store.toJSON()` is overridden to strip `whatsappAccessToken` and
`whatsappVerifyToken` even if a future query forgets to exclude them —
belt-and-braces protection against ever leaking those to a client.

## Relationships (Phase 1)

```
User (many) ──belongs to──> (one) Store
```

Every business owner (`role: 'owner'`) has exactly one `storeId`. Later
phases add `Product`, `Customer`, `Order`, `Payment`,
`WhatsAppConversation`, and `Subscription` — each of those will carry its
own `storeId` so every query can be scoped with `Product.find({ storeId: req.user.storeId })`,
guaranteeing one business can never see another's data.
